package com.example

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

import org.json.JSONObject

class ContractViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ContractRepository
    private val officeRepository: OfficeRepository
    val bluetoothPrinterManager: BluetoothPrinterManager

    private val _officeInfo = MutableStateFlow(OfficeInfo())
    val officeInfo: StateFlow<OfficeInfo> = _officeInfo.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ContractRepository(database.contractDao())
        officeRepository = OfficeRepositoryImpl(SettingsManager.getInstance(application))
        bluetoothPrinterManager = BluetoothPrinterManager(application)
        _officeInfo.value = officeRepository.getOfficeInfo()
        observeSavedContracts()
    }

    fun refreshOfficeInfo() {
        _officeInfo.value = officeRepository.getOfficeInfo()
        generateCurrentPreviewBitmap()
    }

    // 1. اختيار نوع العقد المباشر
    private val _selectedContractType = MutableStateFlow(ContractType.REAL_ESTATE)
    val selectedContractType: StateFlow<ContractType> = _selectedContractType.asStateFlow()

    // 2. حالات نماذج الإدخال للعقود الثلاثة
    private val _realEstateContract = MutableStateFlow(RealEstateContract())
    val realEstateContract: StateFlow<RealEstateContract> = _realEstateContract.asStateFlow()

    private val _carSaleContract = MutableStateFlow(CarSaleContract())
    val carSaleContract: StateFlow<CarSaleContract> = _carSaleContract.asStateFlow()

    private val _rentalContract = MutableStateFlow(RentalContract())
    val rentalContract: StateFlow<RentalContract> = _rentalContract.asStateFlow()

    private val _motorcycleContract = MutableStateFlow(MotorcycleContract())
    val motorcycleContract: StateFlow<MotorcycleContract> = _motorcycleContract.asStateFlow()

    // 3. حالة معاينة العقد وصورة الـ A4 Canvas
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _showPreviewDialog = MutableStateFlow(false)
    val showPreviewDialog: StateFlow<Boolean> = _showPreviewDialog.asStateFlow()

    // 4. حالة طباعة البلوتوث والأجهزة المقترنة
    val printerState: StateFlow<PrinterState> = bluetoothPrinterManager.printerState
    val selectedPaperType: StateFlow<PrinterPaperType> = bluetoothPrinterManager.selectedPaperType

    private val _pairedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val pairedDevices: StateFlow<List<BluetoothDevice>> = _pairedDevices.asStateFlow()

    private val _showPrinterDialog = MutableStateFlow(false)
    val showPrinterDialog: StateFlow<Boolean> = _showPrinterDialog.asStateFlow()

    fun setPrinterPaperType(type: PrinterPaperType) {
        bluetoothPrinterManager.setPaperType(type)
    }

    // 5. الأرشيف والعقود المحفوظة
    private val _savedContractsList = MutableStateFlow<List<ContractEntity>>(emptyList())
    val savedContractsList: StateFlow<List<ContractEntity>> = _savedContractsList.asStateFlow()

    private fun observeSavedContracts() {
        viewModelScope.launch {
            repository.allContracts.collectLatest { list ->
                _savedContractsList.value = list
            }
        }
    }

    fun setContractType(type: ContractType) {
        _selectedContractType.value = type
        generateCurrentPreviewBitmap()
    }

    // تحديث بيانات عقد العقارات
    fun updateRealEstateContract(update: (RealEstateContract) -> RealEstateContract) {
        _realEstateContract.value = update(_realEstateContract.value)
    }

    // تحديث بيانات عقد السيارات
    fun updateCarSaleContract(update: (CarSaleContract) -> CarSaleContract) {
        _carSaleContract.value = update(_carSaleContract.value)
    }

    // تحديث بيانات عقد الإيجار
    fun updateRentalContract(update: (RentalContract) -> RentalContract) {
        _rentalContract.value = update(_rentalContract.value)
    }

    // تحديث بيانات عقد الدراجات والتكتك
    fun updateMotorcycleContract(update: (MotorcycleContract) -> MotorcycleContract) {
        _motorcycleContract.value = update(_motorcycleContract.value)
    }

    /**
     * إفراغ جميع حقول العقد الحالي
     */
    fun clearCurrentContractFields() {
        when (_selectedContractType.value) {
            ContractType.REAL_ESTATE -> _realEstateContract.value = RealEstateContract()
            ContractType.CAR_SALE -> _carSaleContract.value = CarSaleContract()
            ContractType.RENTAL -> _rentalContract.value = RentalContract()
            ContractType.MOTORCYCLE -> _motorcycleContract.value = MotorcycleContract()
        }
        generateCurrentPreviewBitmap()
    }

    /**
     * توليد صورة معاينة A4 وفقاً للعقد الحالي
     */
    fun generateCurrentPreviewBitmap(): Bitmap {
        val currentOffice = _officeInfo.value
        val context = getApplication<Application>()
        val bitmap = when (_selectedContractType.value) {
            ContractType.REAL_ESTATE -> FormGenerator.renderRealEstateContractBitmap(_realEstateContract.value, currentOffice, context)
            ContractType.CAR_SALE -> FormGenerator.renderCarSaleContractBitmap(_carSaleContract.value, currentOffice, context)
            ContractType.RENTAL -> FormGenerator.renderRentalContractBitmap(_rentalContract.value, currentOffice, context)
            ContractType.MOTORCYCLE -> FormGenerator.renderMotorcycleContractBitmap(_motorcycleContract.value, currentOffice, context)
        }
        _previewBitmap.value = bitmap
        return bitmap
    }

    fun openPreviewDialog() {
        generateCurrentPreviewBitmap()
        _showPreviewDialog.value = true
    }

    fun closePreviewDialog() {
        _showPreviewDialog.value = false
    }

    /**
     * فتح حوار طباعة البلوتوث وتحديث قائمة الأجهزة
     */
    fun openBluetoothPrinterDialog() {
        refreshPairedDevices()
        _showPrinterDialog.value = true
    }

    fun closeBluetoothPrinterDialog() {
        _showPrinterDialog.value = false
        bluetoothPrinterManager.resetState()
    }

    fun refreshPairedDevices() {
        _pairedDevices.value = bluetoothPrinterManager.getPairedDevices()
    }

    fun printToBluetoothDevice(device: BluetoothDevice) {
        val bitmap = _previewBitmap.value ?: generateCurrentPreviewBitmap()
        viewModelScope.launch {
            bluetoothPrinterManager.printBitmapToBluetoothPrinter(device, bitmap)
        }
    }

    /**
     * حفظ العقد الحالي في قاعدة بيانات الأرشيف
     */
    fun saveContractToArchive() {
        viewModelScope.launch {
            val type = _selectedContractType.value
            val (title, primaryParty, secondaryParty, summaryJson) = when (type) {
                ContractType.REAL_ESTATE -> {
                    val c = _realEstateContract.value
                    Quad("عقد عقار - ${c.propertyType.ifBlank { "سكني" }}", c.sellerName, c.buyerName, realEstateToJson(c))
                }
                ContractType.CAR_SALE -> {
                    val c = _carSaleContract.value
                    Quad("عقد سيارة - ${c.carBrandAndType.ifBlank { "مركبة" }}", c.sellerName, c.buyerName, carSaleToJson(c))
                }
                ContractType.RENTAL -> {
                    val c = _rentalContract.value
                    Quad("عقد إيجار - ${c.propertyLocation.ifBlank { "عقار" }}", c.lessorName, c.lesseeName, rentalToJson(c))
                }
                ContractType.MOTORCYCLE -> {
                    val c = _motorcycleContract.value
                    Quad("عقد دراجة/تكتك - ${c.brand.ifBlank { "دراجة" }}", c.sellerName, c.buyerName, motorcycleToJson(c))
                }
            }

            val entity = ContractEntity(
                contractType = type.name,
                title = title,
                primaryPartyName = primaryParty,
                secondaryPartyName = secondaryParty,
                jsonContent = summaryJson
            )
            repository.saveContract(entity)
        }
    }

    /**
     * استرجاع عقد محدد من الأرشيف وإعادة فتحه للطباعة والمعاينة
     */
    fun loadContractFromArchive(entity: ContractEntity) {
        val type = try {
            ContractType.valueOf(entity.contractType)
        } catch (e: Exception) {
            ContractType.REAL_ESTATE
        }
        _selectedContractType.value = type

        when (type) {
            ContractType.REAL_ESTATE -> {
                _realEstateContract.value = jsonToRealEstate(entity.jsonContent)
            }
            ContractType.CAR_SALE -> {
                _carSaleContract.value = jsonToCarSale(entity.jsonContent)
            }
            ContractType.RENTAL -> {
                _rentalContract.value = jsonToRental(entity.jsonContent)
            }
            ContractType.MOTORCYCLE -> {
                _motorcycleContract.value = jsonToMotorcycle(entity.jsonContent)
            }
        }

        openPreviewDialog()
    }

    fun deleteSavedContract(id: Long) {
        viewModelScope.launch {
            repository.deleteContract(id)
        }
    }

    private fun realEstateToJson(c: RealEstateContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerPhone", c.buyerPhone)
            put("propertyType", c.propertyType)
            put("propertyArea", c.propertyArea)
            put("plotSequenceNo", c.plotSequenceNo)
            put("neighborhood", c.neighborhood)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("depositPrice", c.depositPrice)
            put("remainingPrice", c.remainingPrice)
            put("penaltySellerAmount", c.penaltySellerAmount)
            put("penaltyBuyerAmount", c.penaltyBuyerAmount)
            put("contractPlace", c.contractPlace)
            put("contractDate", c.contractDate)
            put("additionalNotes", c.additionalNotes)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
        }.toString()
    }

    private fun jsonToRealEstate(jsonStr: String): RealEstateContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return RealEstateContract()
        return try {
            val j = JSONObject(jsonStr)
            RealEstateContract(
                contractNo = j.optString("contractNo", "0025"),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                propertyType = j.optString("propertyType", "دار سكني"),
                propertyArea = j.optString("propertyArea", ""),
                plotSequenceNo = j.optString("plotSequenceNo", ""),
                neighborhood = j.optString("neighborhood", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                depositPrice = j.optString("depositPrice", ""),
                remainingPrice = j.optString("remainingPrice", ""),
                penaltySellerAmount = j.optString("penaltySellerAmount", ""),
                penaltyBuyerAmount = j.optString("penaltyBuyerAmount", ""),
                contractPlace = j.optString("contractPlace", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                additionalNotes = j.optString("additionalNotes", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", "")
            )
        } catch (e: Exception) {
            RealEstateContract()
        }
    }

    private fun carSaleToJson(c: CarSaleContract): String {
        return JSONObject().apply {
            put("galleryName", c.galleryName)
            put("galleryPhone", c.galleryPhone)
            put("galleryAddress", c.galleryAddress)
            put("contractNo", c.contractNo)
            put("carLegalOwner", c.carLegalOwner)
            put("ownerAddress", c.ownerAddress)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerPhone", c.buyerPhone)
            put("carCategory", c.carCategory)
            put("carBrandAndType", c.carBrandAndType)
            put("modelYear", c.modelYear)
            put("color", c.color)
            put("annualRegNumber", c.annualRegNumber)
            put("engineNumber", c.engineNumber)
            put("chassisNumber", c.chassisNumber)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("paidAmount", c.paidAmount)
            put("remainingAmount", c.remainingAmount)
            put("contractDate", c.contractDate)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
            put("witnessName", c.witnessName)
            put("organizerName", c.organizerName)
        }.toString()
    }

    private fun jsonToCarSale(jsonStr: String): CarSaleContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return CarSaleContract()
        return try {
            val j = JSONObject(jsonStr)
            CarSaleContract(
                galleryName = j.optString("galleryName", ""),
                galleryPhone = j.optString("galleryPhone", ""),
                galleryAddress = j.optString("galleryAddress", ""),
                contractNo = j.optString("contractNo", "000100"),
                carLegalOwner = j.optString("carLegalOwner", ""),
                ownerAddress = j.optString("ownerAddress", ""),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                carCategory = j.optString("carCategory", "خصوصي"),
                carBrandAndType = j.optString("carBrandAndType", ""),
                modelYear = j.optString("modelYear", ""),
                color = j.optString("color", ""),
                annualRegNumber = j.optString("annualRegNumber", ""),
                engineNumber = j.optString("engineNumber", ""),
                chassisNumber = j.optString("chassisNumber", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                paidAmount = j.optString("paidAmount", ""),
                remainingAmount = j.optString("remainingAmount", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", ""),
                witnessName = j.optString("witnessName", ""),
                organizerName = j.optString("organizerName", "")
            )
        } catch (e: Exception) {
            CarSaleContract()
        }
    }

    private fun rentalToJson(c: RentalContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sequenceNumber", c.sequenceNumber)
            put("doorsNumber", c.doorsNumber)
            put("lessorName", c.lessorName)
            put("lesseeName", c.lesseeName)
            put("rentedPropertyDescription", c.rentedPropertyDescription)
            put("propertyLocation", c.propertyLocation)
            put("neighborhood", c.neighborhood)
            put("alleyNumber", c.alleyNumber)
            put("leaseDuration", c.leaseDuration)
            put("startDate", c.startDate)
            put("endDate", c.endDate)
            put("rentAmountWords", c.rentAmountWords)
            put("rentAmountNumber", c.rentAmountNumber)
            put("returnToLesseeText", c.returnToLesseeText)
            put("dwellingRightDetails", c.dwellingRightDetails)
            put("dailyDelayFee", c.dailyDelayFee)
            put("propertyTaxOwner", c.propertyTaxOwner)
            put("signDate", c.signDate)
            put("additionalClauses", c.additionalClauses)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
        }.toString()
    }

    private fun jsonToRental(jsonStr: String): RentalContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return RentalContract()
        return try {
            val j = JSONObject(jsonStr)
            RentalContract(
                contractNo = j.optString("contractNo", "1024"),
                sequenceNumber = j.optString("sequenceNumber", ""),
                doorsNumber = j.optString("doorsNumber", ""),
                lessorName = j.optString("lessorName", ""),
                lesseeName = j.optString("lesseeName", ""),
                rentedPropertyDescription = j.optString("rentedPropertyDescription", ""),
                propertyLocation = j.optString("propertyLocation", ""),
                neighborhood = j.optString("neighborhood", ""),
                alleyNumber = j.optString("alleyNumber", ""),
                leaseDuration = j.optString("leaseDuration", ""),
                startDate = j.optString("startDate", FormatUtils.getTodayDateString()),
                endDate = j.optString("endDate", ""),
                rentAmountWords = j.optString("rentAmountWords", ""),
                rentAmountNumber = j.optString("rentAmountNumber", ""),
                returnToLesseeText = j.optString("returnToLesseeText", ""),
                dwellingRightDetails = j.optString("dwellingRightDetails", ""),
                dailyDelayFee = j.optString("dailyDelayFee", ""),
                propertyTaxOwner = j.optString("propertyTaxOwner", ""),
                signDate = j.optString("signDate", FormatUtils.getTodayDateString()),
                additionalClauses = j.optString("additionalClauses", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", "")
            )
        } catch (e: Exception) {
            RentalContract()
        }
    }

    private fun motorcycleToJson(c: MotorcycleContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerNeighborhood", c.sellerNeighborhood)
            put("sellerAlley", c.sellerAlley)
            put("sellerHouse", c.sellerHouse)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerIdIssueDate", c.sellerIdIssueDate)
            put("sellerRegistry", c.sellerRegistry)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerNeighborhood", c.buyerNeighborhood)
            put("buyerAlley", c.buyerAlley)
            put("buyerHouse", c.buyerHouse)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerIdIssueDate", c.buyerIdIssueDate)
            put("buyerRegistry", c.buyerRegistry)
            put("buyerPhone", c.buyerPhone)
            put("registeredNumber", c.registeredNumber)
            put("vehicleType", c.vehicleType)
            put("contactPhone", c.contactPhone)
            put("color", c.color)
            put("engineCc", c.engineCc)
            put("brand", c.brand)
            put("engineNumber", c.engineNumber)
            put("chassisNumber", c.chassisNumber)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("paidAmount", c.paidAmount)
            put("remainingAmount", c.remainingAmount)
            put("possessorName", c.possessorName)
            put("possessorAddress", c.possessorAddress)
            put("possessorNeighborhood", c.possessorNeighborhood)
            put("possessorAlley", c.possessorAlley)
            put("possessorHouse", c.possessorHouse)
            put("possessorPhone", c.possessorPhone)
            put("possessorIdNumber", c.possessorIdNumber)
            put("notes", c.notes)
            put("contractDate", c.contractDate)
            put("contractTime", c.contractTime)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
            put("witnessName", c.witnessName)
        }.toString()
    }

    private fun jsonToMotorcycle(jsonStr: String): MotorcycleContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return MotorcycleContract()
        return try {
            val j = JSONObject(jsonStr)
            MotorcycleContract(
                contractNo = j.optString("contractNo", "004126"),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerNeighborhood = j.optString("sellerNeighborhood", ""),
                sellerAlley = j.optString("sellerAlley", ""),
                sellerHouse = j.optString("sellerHouse", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerIdIssueDate = j.optString("sellerIdIssueDate", ""),
                sellerRegistry = j.optString("sellerRegistry", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerNeighborhood = j.optString("buyerNeighborhood", ""),
                buyerAlley = j.optString("buyerAlley", ""),
                buyerHouse = j.optString("buyerHouse", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerIdIssueDate = j.optString("buyerIdIssueDate", ""),
                buyerRegistry = j.optString("buyerRegistry", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                registeredNumber = j.optString("registeredNumber", ""),
                vehicleType = j.optString("vehicleType", "دراجة نارية"),
                contactPhone = j.optString("contactPhone", ""),
                color = j.optString("color", ""),
                engineCc = j.optString("engineCc", ""),
                brand = j.optString("brand", ""),
                engineNumber = j.optString("engineNumber", ""),
                chassisNumber = j.optString("chassisNumber", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                paidAmount = j.optString("paidAmount", ""),
                remainingAmount = j.optString("remainingAmount", ""),
                possessorName = j.optString("possessorName", ""),
                possessorAddress = j.optString("possessorAddress", ""),
                possessorNeighborhood = j.optString("possessorNeighborhood", ""),
                possessorAlley = j.optString("possessorAlley", ""),
                possessorHouse = j.optString("possessorHouse", ""),
                possessorPhone = j.optString("possessorPhone", ""),
                possessorIdNumber = j.optString("possessorIdNumber", ""),
                notes = j.optString("notes", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                contractTime = j.optString("contractTime", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", ""),
                witnessName = j.optString("witnessName", "")
            )
        } catch (e: Exception) {
            MotorcycleContract()
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
