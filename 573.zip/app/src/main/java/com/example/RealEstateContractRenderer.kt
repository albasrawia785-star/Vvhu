package com.example

import android.content.Context
import android.graphics.*

/**
 * RealEstateContractRenderer: محرك رسم عقد بيع وشراء الدور والأراضي السكنية والزراعية
 * تصميم عراقي رسمي متناسق وموزع بدقة على ورقة A4 بدون فراغات زائدة وبخطوط واضحة.
 */
class RealEstateContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RealEstateContract ?: RealEstateContract()

        val margin = activeTemplate.marginDp.coerceAtLeast(30f)
        val pageW = A4_WIDTH
        val pageH = A4_HEIGHT
        val contentW = pageW - (margin * 2)

        val primaryBlue = try { Color.parseColor(activeTemplate.primaryColorHex) } catch (e: Exception) { Color.parseColor("#1E3A8A") }
        val accentBlue = try { Color.parseColor(activeTemplate.secondaryColorHex) } catch (e: Exception) { Color.parseColor("#2563EB") }
        val lightBgBlue = try { Color.parseColor(activeTemplate.backgroundColorHex) } catch (e: Exception) { Color.parseColor("#F8FAFC") }
        val greenPrimary = primaryBlue
        val redAccent = accentBlue
        val darkText = try { Color.parseColor(activeTemplate.textColorHex) } catch (e: Exception) { Color.parseColor("#0F172A") }

        // ==================== 0. الإطار الخارجي المزدوج ====================
        val outerFrameRect = RectF(margin, margin, pageW - margin, pageH - margin)
        val outerFramePaint = Paint().apply {
            color = primaryBlue
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(outerFrameRect, 18f, 18f, outerFramePaint)

        val innerFrameRect = RectF(margin + 8f, margin + 8f, pageW - margin - 8f, pageH - margin - 8f)
        val innerFramePaint = Paint().apply {
            color = accentBlue
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(innerFrameRect, 14f, 14f, innerFramePaint)

        // ==================== 1. الترويسة الهيدر العلوي ====================
        val headerTop = margin + 15f
        val headerHeight = 160f
        val headerBottom = headerTop + headerHeight

        val cardBgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val cardBorderPaint = Paint().apply {
            color = primaryBlue
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }

        // أ) بطاقة تفاصيل المكتب (اليمين)
        val officeBoxW = 320f
        val officeBoxRect = RectF(pageW - margin - 15f - officeBoxW, headerTop, pageW - margin - 15f, headerBottom)
        canvas.drawRoundRect(officeBoxRect, 14f, 14f, cardBgPaint)
        canvas.drawRoundRect(officeBoxRect, 14f, 14f, cardBorderPaint)

        val officeNameText = officeInfo.officeName.ifEmpty { "مكتب الممتاز العقاري" }
        val officeAddressText = officeInfo.address.ifEmpty { "البصرة - حي الحسين" }
        val officePhoneText = officeInfo.phone.ifEmpty { "07810936783" }

        val officeTitlePaint = Paint().apply {
            color = darkText
            textSize = 23f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val officeInfoPaint = Paint().apply {
            color = primaryBlue
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val oRight = officeBoxRect.right - 20f
        canvas.drawText(officeNameText, oRight, officeBoxRect.top + 42f, officeTitlePaint)
        canvas.drawText("📍 $officeAddressText", oRight, officeBoxRect.top + 88f, officeInfoPaint)
        canvas.drawText("📞 $officePhoneText", oRight, officeBoxRect.top + 130f, officeInfoPaint)

        // ب) الترويسة والعنوان الرئيسي في المنتصف
        val centerX = pageW / 2f
        val logoPath = Path().apply {
            moveTo(centerX - 30f, headerTop + 35f)
            lineTo(centerX, headerTop + 10f)
            lineTo(centerX + 30f, headerTop + 35f)
            lineTo(centerX + 22f, headerTop + 35f)
            lineTo(centerX + 22f, headerTop + 52f)
            lineTo(centerX - 22f, headerTop + 52f)
            lineTo(centerX - 22f, headerTop + 35f)
            close()
        }
        val logoPaint = Paint().apply {
            color = primaryBlue
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawPath(logoPath, logoPaint)

        val mainTitlePaint = Paint().apply {
            color = greenPrimary
            textSize = 42f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء", centerX, headerTop + 102f, mainTitlePaint)

        val subtitlePaint = Paint().apply {
            color = redAccent
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("الدور والاراضي السكنية والزراعية", centerX, headerTop + 142f, subtitlePaint)

        // جـ) بطاقتي رقم العقد والتاريخ (اليسار)
        val leftBoxW = 230f
        val leftBoxX = margin + 15f

        // 1. رقم العقد
        val noPillRect = RectF(leftBoxX, headerTop + 10f, leftBoxX + leftBoxW, headerTop + 72f)
        canvas.drawRoundRect(noPillRect, 20f, 20f, cardBgPaint)
        canvas.drawRoundRect(noPillRect, 20f, 20f, cardBorderPaint)
        val noTextPaint = Paint().apply {
            color = redAccent
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("NO : ${data.contractNo.ifEmpty { "0025" }}", noPillRect.centerX(), noPillRect.centerY() + 7f, noTextPaint)

        // 2. التاريخ
        val datePillRect = RectF(leftBoxX, headerTop + 88f, leftBoxX + leftBoxW, headerTop + 150f)
        canvas.drawRoundRect(datePillRect, 20f, 20f, cardBgPaint)
        canvas.drawRoundRect(datePillRect, 20f, 20f, cardBorderPaint)
        val dateTextPaint = Paint().apply {
            color = primaryBlue
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("📅 ${data.contractDate} : التاريخ", datePillRect.centerX(), datePillRect.centerY() + 7f, dateTextPaint)

        // ==================== 2. بطاقتي الطرف الأول والطرف الثاني ====================
        val partyTopY = headerBottom + 25f
        val partyHeight = 285f
        val partyW = (contentW - 30f) / 2f

        val rightPartyRect = RectF(pageW - margin - partyW, partyTopY, pageW - margin, partyTopY + partyHeight)
        val leftPartyRect = RectF(margin, partyTopY, margin + partyW, partyTopY + partyHeight)

        val partyBgPaint = Paint().apply {
            color = lightBgBlue
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        canvas.drawRoundRect(rightPartyRect, 14f, 14f, partyBgPaint)
        canvas.drawRoundRect(rightPartyRect, 14f, 14f, cardBorderPaint)

        canvas.drawRoundRect(leftPartyRect, 14f, 14f, partyBgPaint)
        canvas.drawRoundRect(leftPartyRect, 14f, 14f, cardBorderPaint)

        // شريط عنوان الكارتين
        val headerPillPaint = Paint().apply {
            color = primaryBlue
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val headerTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightPillRect = RectF(rightPartyRect.centerX() - 130f, partyTopY - 18f, rightPartyRect.centerX() + 130f, partyTopY + 22f)
        canvas.drawRoundRect(rightPillRect, 14f, 14f, headerPillPaint)
        canvas.drawText("الطرف الأول (البائع)", rightPartyRect.centerX(), partyTopY + 10f, headerTitlePaint)

        val leftPillRect = RectF(leftPartyRect.centerX() - 130f, partyTopY - 18f, leftPartyRect.centerX() + 130f, partyTopY + 22f)
        canvas.drawRoundRect(leftPillRect, 14f, 14f, headerPillPaint)
        canvas.drawText("الطرف الثاني (المشتري)", leftPartyRect.centerX(), partyTopY + 10f, headerTitlePaint)

        // بيانات البائع
        var rY = partyTopY + 60f
        val rRight = rightPartyRect.right - 18f
        val rWidth = rightPartyRect.width() - 36f

        val redLabelPaint = Paint().apply {
            color = redAccent
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        drawFieldWithLabel(canvas, "البائع :", data.sellerName, rRight, rY, rWidth, redLabelPaint)
        rY += 54f
        drawFieldWithLabel(canvas, "العنوان :", data.sellerAddress, rRight, rY, rWidth, redLabelPaint)
        rY += 54f
        drawFieldWithLabel(canvas, "رقم الهوية :", data.sellerIdNumber, rRight, rY, rWidth, redLabelPaint)
        rY += 54f
        drawFieldWithLabel(canvas, "الهاتف :", data.sellerPhone, rRight, rY, rWidth, redLabelPaint)

        // بيانات المشتري
        var lY = partyTopY + 60f
        val lRight = leftPartyRect.right - 18f
        val lWidth = leftPartyRect.width() - 36f

        val greenLabelPaint = Paint().apply {
            color = greenPrimary
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        drawFieldWithLabel(canvas, "المشتري :", data.buyerName, lRight, lY, lWidth, greenLabelPaint)
        lY += 54f
        drawFieldWithLabel(canvas, "العنوان :", data.buyerAddress, lRight, lY, lWidth, greenLabelPaint)
        lY += 54f
        drawFieldWithLabel(canvas, "رقم الهوية :", data.buyerIdNumber, lRight, lY, lWidth, greenLabelPaint)
        lY += 54f
        drawFieldWithLabel(canvas, "الهاتف :", data.buyerPhone, lRight, lY, lWidth, greenLabelPaint)

        // ==================== 3. نص مقدمة الاتفاق ====================
        var currY = partyTopY + partyHeight + 35f
        val introTextPaint = Paint().apply {
            color = greenPrimary
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("لقد تم الاتفاق بين الطرفين على انعقاد هذا العقد بالشروط الاتية :", pageW - margin - 10f, currY, introTextPaint)

        // ==================== 4. بنود العقد وشروطه ====================
        currY += 50f

        // اولا - أ
        drawFirstClauseHeader(canvas, currY, margin + 10f)
        currY += 54f

        // نوع الملك / المساحة
        val halfW = (contentW - 40f) / 2f
        drawFieldWithLabel(canvas, "نوع الملك :", data.propertyType.ifEmpty { "دار سكني" }, pageW - margin - 10f, currY, halfW, redLabelPaint)
        drawFieldWithLabel(canvas, "المساحة :", data.propertyArea, pageW - margin - 10f - halfW - 30f, currY, halfW, redLabelPaint)
        currY += 54f

        // الرقم والتسلسل / المحلة
        drawFieldWithLabel(canvas, "الرقم والتسلسل :", data.plotSequenceNo, pageW - margin - 10f, currY, halfW, redLabelPaint)
        drawFieldWithLabel(canvas, "المحلة :", data.neighborhood, pageW - margin - 10f - halfW - 30f, currY, halfW, redLabelPaint)
        currY += 55f

        // ب . بدل البيع المتفق عليه
        val formattedTotalPrice = FormatUtils.formatMoneyInput(data.totalPrice)
        val displayTotalPrice = buildString {
            if (formattedTotalPrice.isNotBlank()) append(formattedTotalPrice) else if (data.totalPrice.isNotBlank()) append(data.totalPrice)
            if (data.totalPriceWords.isNotBlank()) {
                if (isNotEmpty()) append(" دينار (")
                append(data.totalPriceWords)
                append(")")
            } else if (isNotEmpty()) {
                append(" دينار")
            }
        }
        drawFieldWithLabel(canvas, "ب - بدل البيع المتفق عليه :", displayTotalPrice, pageW - margin - 10f, currY, contentW - 20f, redLabelPaint)
        currY += 55f

        // جـ . العربون الذي تم قبضه
        val formattedDeposit = FormatUtils.formatMoneyInput(data.depositPrice)
        val displayDeposit = if (formattedDeposit.isNotBlank()) "$formattedDeposit دينار" else data.depositPrice
        drawFieldWithLabel(canvas, "ج - العربون الذي تم قبضه :", displayDeposit, pageW - margin - 10f, currY, contentW - 20f, redLabelPaint)
        currY += 55f

        // الباقي
        val formattedRemaining = FormatUtils.formatMoneyInput(data.remainingPrice)
        val displayRemaining = if (formattedRemaining.isNotBlank()) "$formattedRemaining دينار" else data.remainingPrice
        drawFieldWithLabel(canvas, "الباقي :", displayRemaining, pageW - margin - 10f, currY, contentW - 20f, redLabelPaint)
        currY += 60f

        // د . نكول البائع
        val penaltySellerStr = data.penaltySellerAmount
        currY = drawLongClauseWithField(
            canvas = canvas,
            prefixText = "د . اذا امتنع الطرف الاول ( البائع ) عن اجراء التقدير او البيع باي صورة فانه ملزم باعادة العربون ويدفع تعويضات الى الطرف الثاني ( المشتري ) قدرها :",
            valueText = penaltySellerStr,
            startY = currY,
            marginRight = margin + 10f,
            fullWidth = contentW - 20f
        )
        currY += 35f

        // ثانيا - نكول المشتري
        val penaltyBuyerStr = data.penaltyBuyerAmount
        currY = drawLongClauseWithField(
            canvas = canvas,
            prefixText = "ثانيا - يعترف الطرف الثاني ( المشتري ) بأنه قد قبل الشراء وفي حالة عدم التقدير او النكول عن الشراء وتأدية قصور البدل فانه يتعهد بتأدية تعويضات الى الطرف الاول ( البائع ) قدرها :",
            valueText = penaltyBuyerStr,
            startY = currY,
            marginRight = margin + 10f,
            fullWidth = contentW - 20f
        )
        currY += 35f

        // ثالثا
        drawNormalClause(canvas, "ثالثا - يحق للطرف الثاني ( المشتري ) تقدير الملك لمن يشاء .", currY, margin + 10f)
        currY += 52f

        // رابعا
        drawNormalClause(canvas, "رابعا : كل مكاتبة غير مختومة بختم المكتب تعتبر باطلة", currY, margin + 10f)
        currY += 52f

        // خامسا
        drawNormalClause(canvas, "خامسا - لا تسترجع الدلالية عند حصول اي خلاف بين الطرفين بعد ابرام العقد .", currY, margin + 10f)
        currY += 52f

        // ملاحظات الدلالية
        drawNormalClause(canvas, "ملاحظات - نسبة الدلالية ٢% والمكتب غير مسؤول بعد التقدير عن الفقرات الاضافية .", currY, margin + 10f)
        currY += 60f

        // التراضي والمكان والتاريخ
        val place = data.contractPlace.ifEmpty { officeInfo.address.ifEmpty { "البصرة - حي الحسين" } }
        val date = data.contractDate
        val finalClauseText = "فيما على حصول التراضي والايجاب والقبول حرر هذا العقد في  $place  بتاريخ  $date"
        val finalClausePaint = Paint().apply {
            color = darkText
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(finalClauseText, pageW - margin - 10f, currY, finalClausePaint)
        currY += 55f

        // ملاحظات اضافية
        val notesTitlePaint = Paint().apply {
            color = redAccent
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("ملاحظات اضافية :", pageW - margin - 10f, currY, notesTitlePaint)
        currY += 35f

        val dotPaintLine = Paint().apply {
            color = Color.GRAY
            textSize = 20f
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        if (data.additionalNotes.isNotBlank()) {
            drawRtlText(
                canvas = canvas,
                text = data.additionalNotes,
                x = pageW - margin - 10f,
                y = currY,
                maxWidth = contentW - 20f,
                paint = valuePaint.apply { textSize = 20f },
                align = Paint.Align.RIGHT
            )
            currY += 40f
        } else {
            val dotsLine = "................................................................................................................................................"
            canvas.drawText(dotsLine, pageW - margin - 10f, currY, dotPaintLine)
            canvas.drawText(dotsLine, pageW - margin - 10f, currY + 35f, dotPaintLine)
            currY += 70f
        }

        // ==================== 5. التواقيع في أسفل الصفحة ====================
        val sigBoxRect = RectF(margin + 10f, pageH - margin - 185f, pageW - margin - 10f, pageH - margin - 70f)
        canvas.drawRoundRect(sigBoxRect, 14f, 14f, partyBgPaint)
        canvas.drawRoundRect(sigBoxRect, 14f, 14f, cardBorderPaint)

        val colW = sigBoxRect.width() / 4f
        val sigY = sigBoxRect.centerY() + 7f

        val redSigPaint = Paint().apply {
            color = redAccent
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val darkSigPaint = Paint().apply {
            color = darkText
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val greenSigPaint = Paint().apply {
            color = greenPrimary
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        // 1. الطرف الأول/البائع (اليمين)
        canvas.drawText("الطرف الأول/البائع", sigBoxRect.right - (colW * 0.5f), sigY, redSigPaint)

        // 2. الشاهد الأول
        val w1 = if (data.witness1Name.isNotBlank()) "الشاهد: ${data.witness1Name}" else "الشاهد الاول"
        canvas.drawText(w1, sigBoxRect.right - (colW * 1.5f), sigY, darkSigPaint)

        // 3. الشاهد الثاني
        val w2 = if (data.witness2Name.isNotBlank()) "الشاهد: ${data.witness2Name}" else "الشاهد الثاني"
        canvas.drawText(w2, sigBoxRect.right - (colW * 2.5f), sigY, darkSigPaint)

        // 4. الطرف الثاني/المشتري (اليسار)
        canvas.drawText("الطرف الثاني/المشتري", sigBoxRect.right - (colW * 3.5f), sigY, greenSigPaint)
    }

    private fun drawFieldWithLabel(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        lblPaint: Paint
    ) {
        lblPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(label, x, y, lblPaint)

        val labelW = lblPaint.measureText(label) + 12f
        val valueX = x - labelW
        val availableW = totalWidth - labelW

        val valPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        if (value.isBlank()) {
            val dotsCount = (availableW / 8f).toInt().coerceAtLeast(4)
            val dots = ".".repeat(dotsCount)
            val dPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 20f
                textAlign = Paint.Align.RIGHT
                isAntiAlias = true
            }
            canvas.drawText(dots, valueX, y, dPaint)
        } else {
            drawRtlText(
                canvas = canvas,
                text = value,
                x = valueX,
                y = y,
                maxWidth = availableW,
                paint = valPaint,
                align = Paint.Align.RIGHT
            )
        }
    }

    private fun drawFirstClauseHeader(canvas: Canvas, y: Float, xRight: Float) {
        val redP = Paint().apply {
            color = Color.parseColor("#D32F2F")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val darkP = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val greenP = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        var curX = A4_WIDTH - xRight

        canvas.drawText("اولا - أ - ", curX, y, redP)
        curX -= redP.measureText("اولا - أ - ")

        canvas.drawText("يعترف الطرف الأول ", curX, y, darkP)
        curX -= darkP.measureText("يعترف الطرف الأول ")

        canvas.drawText("( البائع ) ", curX, y, redP)
        curX -= redP.measureText("( البائع ) ")

        canvas.drawText("بأنه قد باع للطرف الثاني ", curX, y, darkP)
        curX -= darkP.measureText("بأنه قد باع للطرف الثاني ")

        canvas.drawText("( المشتري ) ", curX, y, greenP)
        curX -= greenP.measureText("( المشتري ) ")

        canvas.drawText("الملك المفصل فيما يلي .", curX, y, darkP)
    }

    private fun drawLongClauseWithField(
        canvas: Canvas,
        prefixText: String,
        valueText: String,
        startY: Float,
        marginRight: Float,
        fullWidth: Float
    ): Float {
        val textPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val lines = splitTextToLines(prefixText, textPaint, fullWidth)
        var lineY = startY
        for (i in lines.indices) {
            val line = lines[i]
            canvas.drawText(line, A4_WIDTH - marginRight, lineY, textPaint)
            lineY += 32f
        }

        val valPaint = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val formattedVal = FormatUtils.formatMoneyInput(valueText)
        val displayVal = when {
            formattedVal.isNotBlank() -> "$formattedVal دينار"
            valueText.isNotBlank() -> valueText
            else -> ""
        }

        if (displayVal.isBlank()) {
            val dots = "................................................................................"
            val dPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 20f
                textAlign = Paint.Align.RIGHT
                isAntiAlias = true
            }
            canvas.drawText(dots, A4_WIDTH - marginRight, lineY, dPaint)
        } else {
            drawRtlText(
                canvas = canvas,
                text = "المبلغ : $displayVal",
                x = A4_WIDTH - marginRight,
                y = lineY,
                maxWidth = fullWidth,
                paint = valPaint,
                align = Paint.Align.RIGHT
            )
        }

        return lineY
    }

    private fun splitTextToLines(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    private fun drawNormalClause(canvas: Canvas, text: String, y: Float, marginRight: Float) {
        val darkP = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(text, A4_WIDTH - marginRight, y, darkP)
    }
}
