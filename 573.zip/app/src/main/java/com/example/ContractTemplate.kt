package com.example

enum class TemplateCategory(val titleAr: String) {
    ALL("الكل"),
    OFFICIAL("رسمية"),
    LUXURY("فاخرة"),
    MODERN("حديثة"),
    BUSINESS("مكاتب وعقارات"),
    COLOR("ملونة"),
    PRINT("طباعة سريعة"),
    MINIMAL("بسيطة")
}

enum class HeaderType {
    STANDARD,
    LARGE_BANNER,
    COMPACT,
    MINIMAL_LINE
}

/**
 * نموذج قالب العقد الشامل (ContractTemplate)
 */
data class ContractTemplate(
    val id: String,
    val nameAr: String,
    val descriptionAr: String,
    val category: TemplateCategory = TemplateCategory.OFFICIAL,
    val primaryColorHex: String = "#0F172A",
    val secondaryColorHex: String = "#1E3A8A",
    val textColorHex: String = "#0F172A",
    val borderColorHex: String = "#94A3B8",
    val backgroundColorHex: String = "#FFFFFF",
    val titleColorHex: String = "#0F172A",
    val hasFrame: Boolean = true,
    val isDoubleFrame: Boolean = true,
    val hasLogo: Boolean = true,
    val headerType: HeaderType = HeaderType.STANDARD,
    val borderWidth: Float = 1.0f,
    val fontScale: Float = 1.0f,
    val headerTextSize: Float = 34f,
    val showPageNumber: Boolean = true,
    val isDefault: Boolean = false,
    val marginDp: Float = 35f,
    val paragraphSpacingDp: Float = 8f,

    // حقول التوافق المباشر مع النماذج السابقة
    val contractType: ContractType? = null,
    val title: String = nameAr,
    val subtitle: String = descriptionAr,
    val headerImageAssetLeft: String = "",
    val headerImageAssetRight: String = ""
)
