package com.example

/**
 * نقطة الإحداثيات (X, Y) المستخرجة بناءً على مقاس صفحة A4 القياسية
 * Canvas A4 Grid Dimensions: Width = 595f, Height = 842f (Points)
 */
data class Point2D(val x: Float, val y: Float)

/**
 * خريطة إحداثيات عقد بيع وشراء العقارات (الدور والأراضي السكنية والزراعية)
 * مستخرجة بدقة من نموذج صورة العقد الملونة
 */
object RealEstateCoordinates {
    const val A4_WIDTH_PTS = 595f
    const val A4_HEIGHT_PTS = 842f

    // رقم العقد الهيدر (أعلى اليسار)
    val contractNo = Point2D(105f, 198f)

    // مربع الطرف الأول ( البائع ) - جهة اليمين
    val sellerName = Point2D(435f, 272f)
    val sellerAddress = Point2D(435f, 297f)
    val sellerIdNumber = Point2D(435f, 322f)
    val sellerPhone = Point2D(435f, 347f)

    // مربع الطرف الثاني ( المشتري ) - جهة اليسار
    val buyerName = Point2D(205f, 272f)
    val buyerAddress = Point2D(205f, 297f)
    val buyerIdNumber = Point2D(205f, 322f)
    val buyerPhone = Point2D(205f, 347f)

    // تفاصيل العقار والبنود
    val propertyType = Point2D(450f, 438f)   // نوع الملك
    val propertyArea = Point2D(210f, 438f)   // المساحة
    val plotSequenceNo = Point2D(420f, 465f) // الرقم والتسلسل
    val neighborhood = Point2D(170f, 465f)   // المحلة

    val totalPrice = Point2D(380f, 498f)     // بدل البيع المتفق عليه
    val depositPrice = Point2D(380f, 528f)   // العربون المقبوض
    val remainingPrice = Point2D(150f, 528f) // الباقي

    val sellerPenalty = Point2D(240f, 608f)  // مبلغ التعويض الاتفاقي
    val buyerPenalty = Point2D(240f, 655f)   // مبلغ التضمين الاتفاقي

    val contractDate = Point2D(180f, 706f)   // تاريخ تحرير العقد
    val additionalNotes = Point2D(440f, 736f)// ملاحظات إضافية

    // التواقيع أسفل الورقة (4 أعمدة)
    val sellerSignature = Point2D(515f, 769f)
    val witness1Signature = Point2D(380f, 769f)
    val witness2Signature = Point2D(240f, 769f)
    val buyerSignature = Point2D(95f, 769f)
}

/**
 * خريطة إحداثيات عقد بيع وشراء السيارات (معارض السيارات)
 * مستخرجة بدقة من نموذج صورة العقد الملونة
 */
object CarSaleCoordinates {
    const val A4_WIDTH_PTS = 595f
    const val A4_HEIGHT_PTS = 842f

    val contractNo = Point2D(125f, 228f)
    val carLegalOwner = Point2D(420f, 248f)
    val ownerAddress = Point2D(210f, 248f)

    // مربع الطرف الأول ( البائع )
    val sellerName = Point2D(410f, 320f)
    val sellerAddress = Point2D(410f, 348f)
    val sellerIdNumber = Point2D(410f, 376f)
    val sellerPhone = Point2D(410f, 404f)

    // مربع الطرف الثاني ( المشتري )
    val buyerName = Point2D(190f, 320f)
    val buyerAddress = Point2D(190f, 348f)
    val buyerIdNumber = Point2D(190f, 376f)
    val buyerPhone = Point2D(190f, 404f)

    // تفاصيل ومواصفات المركبة
    val annualRegHeader = Point2D(310f, 462f) // رقم السيارة المرقمة
    val carCategory = Point2D(120f, 462f)      // خصوصي / أجرة / حمل
    val carBrandAndType = Point2D(480f, 495f)  // نوع السيارة
    val modelYear = Point2D(280f, 495f)        // موديل
    val color = Point2D(120f, 495f)            // اللون
    val annualRegNumber = Point2D(480f, 528f)  // رقم السنوية
    val engineNumber = Point2D(230f, 528f)     // رقم المحرك
    val chassisNumber = Point2D(450f, 560f)    // رقم الشاسي

    val totalPrice = Point2D(450f, 590f)       // بدل قدره
    val totalPriceWords = Point2D(220f, 590f)  // كتابةً
    val paidAmount = Point2D(350f, 620f)       // استلم البائع
    val remainingAmount = Point2D(150f, 620f)  // والباقي قدره

    val contractDate = Point2D(210f, 744f)     // حرر بتاريخ

    // التواقيع بالأسفل
    val sellerSignature = Point2D(500f, 784f)
    val witnessSignature = Point2D(360f, 784f)
    val organizerSignature = Point2D(220f, 784f)
    val buyerSignature = Point2D(90f, 784f)
}

/**
 * خريطة إحداثيات عقد الإيجار
 * مستخرجة بدقة من نموذج صورة العقد الملونة
 */
object RentalCoordinates {
    const val A4_WIDTH_PTS = 595f
    const val A4_HEIGHT_PTS = 842f

    val contractNo = Point2D(95f, 265f)
    val sequenceNumber = Point2D(430f, 265f)  // عدد التسلسل
    val doorsNumber = Point2D(430f, 290f)     // رقم الأبواب

    val lessorName = Point2D(430f, 318f)      // تم العقد بين (المؤجر)
    val lesseeName = Point2D(430f, 343f)      // على ما يلي (المستأجر)

    val propertyLocation = Point2D(480f, 398f)// الواقع
    val neighborhood = Point2D(300f, 398f)    // في المحلة
    val alleyNumber = Point2D(180f, 398f)     // زقاق / دار
    val leaseDuration = Point2D(80f, 398f)    // لمدة

    val startDate = Point2D(350f, 422f)       // ابتداءً من
    val endDate = Point2D(350f, 448f)         // إلى نهاية

    val rentAmountWords = Point2D(400f, 475f) // بدل إيجار فقط (كتابة)
    val rentAmountNumber = Point2D(220f, 500f)// المبلغ بالأرقام

    val dailyPenalty = Point2D(200f, 582f)     // إيجار يومي

    val signDate = Point2D(250f, 656f)        // كتبت بتاريخ
    val additionalClauses = Point2D(450f, 696f)// فقرات إضافية

    // التواقيع أسفل الصفحة
    val lessorSignature = Point2D(500f, 754f)
    val lesseeSignature = Point2D(370f, 754f)
    val witness1Signature = Point2D(240f, 754f)
    val witness2Signature = Point2D(110f, 754f)
}

/**
 * خريطة إحداثيات عقد بيع وشراء الدراجات والتكتك والستوتات
 * مستخرجة بدقة من نموذج صورة العقد الملونة المرفقة
 */
object MotorcycleCoordinates {
    const val A4_WIDTH_PTS = 595f
    const val A4_HEIGHT_PTS = 842f

    // رقم الوصل (الهيدر في المنتصف أعلى النموذج)
    val contractNo = Point2D(297f, 192f)

    // الطرف الأول (البائع) - الجهة اليمنى
    val sellerName = Point2D(480f, 236f)
    val sellerAddress = Point2D(480f, 258f)
    val sellerNeighborhood = Point2D(520f, 280f)
    val sellerAlley = Point2D(430f, 280f)
    val sellerHouse = Point2D(350f, 280f)
    val sellerIdNumber = Point2D(430f, 302f)
    val sellerIdIssueDate = Point2D(500f, 324f)
    val sellerRegistry = Point2D(390f, 324f)
    val sellerPhone = Point2D(460f, 346f)

    // الطرف الثاني (المشتري) - الجهة اليسرى
    val buyerName = Point2D(210f, 236f)
    val buyerAddress = Point2D(210f, 258f)
    val buyerNeighborhood = Point2D(250f, 280f)
    val buyerAlley = Point2D(160f, 280f)
    val buyerHouse = Point2D(80f, 280f)
    val buyerIdNumber = Point2D(160f, 302f)
    val buyerIdIssueDate = Point2D(230f, 324f)
    val buyerRegistry = Point2D(120f, 324f)
    val buyerPhone = Point2D(190f, 346f)

    // مواصفات المركبة / الدراجة
    val registeredNumber = Point2D(450f, 385f) // الدراجة المرقمة
    val vehicleType = Point2D(280f, 385f)      // نوع
    val contactPhone = Point2D(110f, 385f)     // موبايل

    val color = Point2D(520f, 408f)            // اللون
    val engineCc = Point2D(380f, 408f)         // الحجم
    val brand = Point2D(270f, 408f)            // الماركة
    val engineNumber = Point2D(100f, 408f)     // رقم المحرك

    val chassisNumber = Point2D(430f, 430f)    // رقم الشاسي
    val totalPrice = Point2D(430f, 452f)       // ببدل قدره
    val paidAmount = Point2D(380f, 475f)       // قبض البائع مبلغ قدره
    val remainingAmount = Point2D(120f, 475f)  // والباقي

    // البائع الحائز
    val possessorName = Point2D(430f, 498f)
    val possessorAddress = Point2D(220f, 498f)
    val possessorNeighborhood = Point2D(500f, 520f)
    val possessorAlley = Point2D(380f, 520f)
    val possessorHouse = Point2D(280f, 520f)
    val possessorPhone = Point2D(110f, 520f)
    val possessorIdNumber = Point2D(380f, 542f)

    // الملاحظات
    val notes = Point2D(450f, 565f)

    // التاريخ والوقت أسفل الوصل
    val contractDate = Point2D(250f, 659f)
    val contractTime = Point2D(110f, 659f)

    // التواقيع
    val sellerSignature = Point2D(480f, 719f)
    val witnessSignature = Point2D(297f, 719f)
    val buyerSignature = Point2D(100f, 719f)
}
