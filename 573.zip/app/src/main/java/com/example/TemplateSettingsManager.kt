package com.example

import android.content.Context
import android.content.SharedPreferences
import androidx.annotation.ColorInt
import android.graphics.Color

/**
 * مدير إعدادات قوالب العقود (TemplateSettingsManager)
 * مسؤول عن حفظ واسترجاع القالب المختار وتخصيصات الألوان والإطارات في SharedPreferences
 */
class TemplateSettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    /**
     * معرف القالب المختار حالياً
     */
    var selectedTemplateId: String
        get() = prefs.getString(KEY_SELECTED_TEMPLATE_ID, ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE.id)
            ?: ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE.id
        set(value) {
            prefs.edit().putString(KEY_SELECTED_TEMPLATE_ID, value).apply()
        }

    /**
     * الحصول على القالب المختار بدون تخصيصات
     */
    fun getSelectedTemplate(): ContractTemplate {
        return ContractTemplateLibrary.getTemplateById(selectedTemplateId)
    }

    /**
     * حفظ خيارات التخصيص
     */
    fun saveCustomizationOptions(options: TemplateCustomizationOptions) {
        prefs.edit()
            .putString(KEY_CUSTOM_HEADER_COLOR, options.customHeaderColorHex)
            .putString(KEY_CUSTOM_TITLE_COLOR, options.customTitleColorHex)
            .putString(KEY_CUSTOM_FRAME_COLOR, options.customFrameColorHex)
            .putString(KEY_CUSTOM_TEXT_COLOR, options.customTextColorHex)
            .putFloat(KEY_FONT_SIZE_SCALE, options.fontSizeScale)
            .putFloat(KEY_HEADER_SIZE_SCALE, options.headerSizeScale)
            .putFloat(KEY_BORDER_THICKNESS_SCALE, options.borderThicknessScale)
            .putBoolean(KEY_SHOW_LOGO, options.showLogo)
            .putBoolean(KEY_SHOW_FRAME, options.showFrame)
            .putBoolean(KEY_SHOW_PAGE_NUMBER, options.showPageNumber)
            .putFloat(KEY_MARGIN_SCALE, options.marginScale)
            .putFloat(KEY_PARAGRAPH_SPACING_SCALE, options.paragraphSpacingScale)
            .apply()
    }

    /**
     * استرجاع خيارات التخصيص الحالية
     */
    fun getCustomizationOptions(): TemplateCustomizationOptions {
        return TemplateCustomizationOptions(
            customHeaderColorHex = prefs.getString(KEY_CUSTOM_HEADER_COLOR, null),
            customTitleColorHex = prefs.getString(KEY_CUSTOM_TITLE_COLOR, null),
            customFrameColorHex = prefs.getString(KEY_CUSTOM_FRAME_COLOR, null),
            customTextColorHex = prefs.getString(KEY_CUSTOM_TEXT_COLOR, null),
            fontSizeScale = prefs.getFloat(KEY_FONT_SIZE_SCALE, 1.0f),
            headerSizeScale = prefs.getFloat(KEY_HEADER_SIZE_SCALE, 1.0f),
            borderThicknessScale = prefs.getFloat(KEY_BORDER_THICKNESS_SCALE, 1.0f),
            showLogo = prefs.getBoolean(KEY_SHOW_LOGO, true),
            showFrame = prefs.getBoolean(KEY_SHOW_FRAME, true),
            showPageNumber = prefs.getBoolean(KEY_SHOW_PAGE_NUMBER, true),
            marginScale = prefs.getFloat(KEY_MARGIN_SCALE, 1.0f),
            paragraphSpacingScale = prefs.getFloat(KEY_PARAGRAPH_SPACING_SCALE, 1.0f)
        )
    }

    /**
     * حساب وإعادة القالب الفعلي النافذ مع دمج التخصيصات (Effective ContractTemplate)
     */
    fun getEffectiveTemplate(): ContractTemplate {
        val base = getSelectedTemplate()
        val custom = getCustomizationOptions()

        return base.copy(
            primaryColorHex = custom.customHeaderColorHex ?: base.primaryColorHex,
            titleColorHex = custom.customTitleColorHex ?: base.titleColorHex,
            borderColorHex = custom.customFrameColorHex ?: base.borderColorHex,
            textColorHex = custom.customTextColorHex ?: base.textColorHex,
            fontScale = base.fontScale * custom.fontSizeScale,
            headerTextSize = base.headerTextSize * custom.headerSizeScale,
            borderWidth = base.borderWidth * custom.borderThicknessScale,
            hasLogo = custom.showLogo && base.hasLogo,
            hasFrame = custom.showFrame && base.hasFrame,
            showPageNumber = custom.showPageNumber,
            marginDp = base.marginDp * custom.marginScale,
            paragraphSpacingDp = base.paragraphSpacingDp * custom.paragraphSpacingScale
        )
    }

    /**
     * العودة إلى التصميم الأصلي للتطبيق
     */
    fun resetToOriginalDesign() {
        prefs.edit()
            .putString(KEY_SELECTED_TEMPLATE_ID, ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE.id)
            .remove(KEY_CUSTOM_HEADER_COLOR)
            .remove(KEY_CUSTOM_TITLE_COLOR)
            .remove(KEY_CUSTOM_FRAME_COLOR)
            .remove(KEY_CUSTOM_TEXT_COLOR)
            .remove(KEY_FONT_SIZE_SCALE)
            .remove(KEY_HEADER_SIZE_SCALE)
            .remove(KEY_BORDER_THICKNESS_SCALE)
            .remove(KEY_SHOW_LOGO)
            .remove(KEY_SHOW_FRAME)
            .remove(KEY_SHOW_PAGE_NUMBER)
            .remove(KEY_MARGIN_SCALE)
            .remove(KEY_PARAGRAPH_SPACING_SCALE)
            .apply()
    }

    /**
     * إعادة تعيين جميع إعدادات وتخصيصات القوالب إلى الوضع الافتراضي للقالب المختار
     */
    fun resetAllTemplateSettings() {
        prefs.edit()
            .remove(KEY_CUSTOM_HEADER_COLOR)
            .remove(KEY_CUSTOM_TITLE_COLOR)
            .remove(KEY_CUSTOM_FRAME_COLOR)
            .remove(KEY_CUSTOM_TEXT_COLOR)
            .remove(KEY_FONT_SIZE_SCALE)
            .remove(KEY_HEADER_SIZE_SCALE)
            .remove(KEY_BORDER_THICKNESS_SCALE)
            .remove(KEY_SHOW_LOGO)
            .remove(KEY_SHOW_FRAME)
            .remove(KEY_SHOW_PAGE_NUMBER)
            .remove(KEY_MARGIN_SCALE)
            .remove(KEY_PARAGRAPH_SPACING_SCALE)
            .apply()
    }

    companion object {
        private const val PREF_NAME = "contract_template_preferences"
        private const val KEY_SELECTED_TEMPLATE_ID = "selected_template_id"

        private const val KEY_CUSTOM_HEADER_COLOR = "custom_header_color"
        private const val KEY_CUSTOM_TITLE_COLOR = "custom_title_color"
        private const val KEY_CUSTOM_FRAME_COLOR = "custom_frame_color"
        private const val KEY_CUSTOM_TEXT_COLOR = "custom_text_color"
        private const val KEY_FONT_SIZE_SCALE = "font_size_scale"
        private const val KEY_HEADER_SIZE_SCALE = "header_size_scale"
        private const val KEY_BORDER_THICKNESS_SCALE = "border_thickness_scale"
        private const val KEY_SHOW_LOGO = "show_logo"
        private const val KEY_SHOW_FRAME = "show_frame"
        private const val KEY_SHOW_PAGE_NUMBER = "show_page_number"
        private const val KEY_MARGIN_SCALE = "margin_scale"
        private const val KEY_PARAGRAPH_SPACING_SCALE = "paragraph_spacing_scale"

        @Volatile
        private var INSTANCE: TemplateSettingsManager? = null

        fun getInstance(context: Context): TemplateSettingsManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TemplateSettingsManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
