package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * PdfGenerator: مسؤول عن تحويل صور العقود A4 المولدة بواسطة FormGenerator
 * إلى مستندات PDF عالية الدقة ومتوافقة تماماً مع معايير الطباعة والأنظمة المعمارية النظيفة (Clean Architecture).
 */
class PdfGenerator(private val context: Context) {

    companion object {
        const val PDF_WIDTH_PTS = 595
        const val PDF_HEIGHT_PTS = 842
    }

    /**
     * إنشاء ملف PDF عالي الجودة من Bitmap العقد
     */
    fun generatePdfFromBitmap(bitmap: Bitmap, fileName: String = "contract_print.pdf"): File {
        return FormGenerator.generatePdfFromBitmap(bitmap, context, fileName)
    }

    /**
     * توليد وحفظ ملف PDF للعقد تلقائياً باقتطاع ومحاذاة مثالية
     */
    fun generateContractPdf(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo
    ): File {
        return FormGenerator.generateContractPdf(contractData, contractType, officeInfo, context)
    }
}
