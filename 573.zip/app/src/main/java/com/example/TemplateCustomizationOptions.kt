package com.example

/**
 * خيارات التخصيص الإضافية التي يجريها المستخدم على القالب المختار
 */
data class TemplateCustomizationOptions(
    val customHeaderColorHex: String? = null,
    val customTitleColorHex: String? = null,
    val customFrameColorHex: String? = null,
    val customTextColorHex: String? = null,
    val fontSizeScale: Float = 1.0f,
    val headerSizeScale: Float = 1.0f,
    val borderThicknessScale: Float = 1.0f,
    val showLogo: Boolean = true,
    val showFrame: Boolean = true,
    val showPageNumber: Boolean = true,
    val marginScale: Float = 1.0f,
    val paragraphSpacingScale: Float = 1.0f
)
