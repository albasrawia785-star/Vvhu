package com.example

import android.content.Context
import android.graphics.*
import androidx.annotation.ColorInt

/**
 * BaseContractRenderer: المكون الأساسي الموحد لجميع محركات رسم العقود الرسمية على ورقة A4.
 * يطبق مبادئ Clean Architecture و DRY لمنع تكرار كود الرسم، ويضمن:
 * 1. قياسات دقيقة ثابتة مبنية على حجم ورقة A4 القياسية (1240x1754 بكسل).
 * 2. محاذاة RTL عربية صحيحة 100%.
 * 3. تصغير تلقائي لخط النص عند تجاوز الحدود المخصصة لمنع التداخل أو الخروج عن الصفحة.
 * 4. دعم تحميل الصور والأيقونات الاختيارية من مجلد Assets أو Drawables بأمان وبدون فراغات عند غيابها.
 * 5. رسم حقول العقود، البنود القانونية، والتواقيع بمرونة تامة.
 */
abstract class BaseContractRenderer {

    companion object {
        const val A4_WIDTH = 1240f
        const val A4_HEIGHT = 1754f

        // الألوان الموحدة
        @ColorInt val COLOR_PRIMARY = Color.parseColor("#0F172A")    // كحلي فاخر
        @ColorInt val COLOR_SECONDARY = Color.parseColor("#1E3A8A")  // أزرق ملكي
        @ColorInt val COLOR_TEXT = Color.parseColor("#0F172A")       // أسود النص
        @ColorInt val COLOR_LABEL = Color.parseColor("#334155")      // رمادي التسميات
        @ColorInt val COLOR_BORDER = Color.parseColor("#94A3B8")     // إطار العقد
        @ColorInt val COLOR_BG_LIGHT = Color.parseColor("#F8FAFC")   // خلفيات المربعات
        @ColorInt val COLOR_RED_ACCENT = Color.parseColor("#991B1B") // لون الأرقام المميزة
    }

    // فرُش الرسم الجاهزة للأداء العالي
    protected val framePaint = Paint().apply {
        color = COLOR_PRIMARY
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        isAntiAlias = true
    }

    protected val innerFramePaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }

    protected val titlePaint = Paint().apply {
        color = COLOR_PRIMARY
        textSize = 34f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val subtitlePaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 20f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val labelPaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val valuePaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val bodyTextPaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 17f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val dotPaint = Paint().apply {
        color = COLOR_BORDER
        textSize = 16f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    /**
     * القالب الفعال الحالي المستخدم في عملية الرسم
     */
    protected var activeTemplate: ContractTemplate = ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE

    /**
     * الدالة المفتاحية لتوليد صورة العقد (A4 Bitmap)
     */
    fun renderBitmap(
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null,
        overrideTemplate: ContractTemplate? = null
    ): Bitmap {
        // استرجاع القالب المختار أو القالب الممرر خصيصاً للمعاينة
        activeTemplate = overrideTemplate ?: (
            context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplate() }
                ?: ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE
        )

        // تطبيق الألوان والفرُش وفقاً للقالب المختار
        applyTemplatePaints(activeTemplate)

        val bitmap = Bitmap.createBitmap(A4_WIDTH.toInt(), A4_HEIGHT.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgColor = try { Color.parseColor(activeTemplate.backgroundColorHex) } catch (e: Exception) { Color.WHITE }
        canvas.drawColor(bgColor)

        // 1. رسم الإطار حسب إعدادات القالب
        if (activeTemplate.hasFrame) {
            drawA4Borders(canvas)
        }

        // 2. التنفيذ الخاص برسم العقد حسب الفئة الابنة
        drawContractContent(canvas, contractData, officeInfo, context)

        // 3. رسم رقم الصفحة/التذييل السفلي إذا كان مفعلاً
        if (activeTemplate.showPageNumber) {
            drawFooterPageNumber(canvas)
        }

        return bitmap
    }

    /**
     * دالة تحديث الفرُش وفق ألوان وسماكة خطوط القالب
     */
    protected fun applyTemplatePaints(template: ContractTemplate) {
        val primary = try { Color.parseColor(template.primaryColorHex) } catch (e: Exception) { COLOR_PRIMARY }
        val secondary = try { Color.parseColor(template.secondaryColorHex) } catch (e: Exception) { COLOR_SECONDARY }
        val textColor = try { Color.parseColor(template.textColorHex) } catch (e: Exception) { COLOR_TEXT }
        val borderColor = try { Color.parseColor(template.borderColorHex) } catch (e: Exception) { COLOR_BORDER }
        val titleColor = try { Color.parseColor(template.titleColorHex) } catch (e: Exception) { primary }

        framePaint.color = primary
        framePaint.strokeWidth = 3.5f * template.borderWidth

        innerFramePaint.color = borderColor
        innerFramePaint.strokeWidth = (1.0f * template.borderWidth).coerceAtLeast(0.8f)

        titlePaint.color = titleColor
        titlePaint.textSize = template.headerTextSize * template.fontScale

        subtitlePaint.color = secondary
        subtitlePaint.textSize = 20f * template.fontScale

        labelPaint.color = secondary
        labelPaint.textSize = 18f * template.fontScale

        valuePaint.color = textColor
        valuePaint.textSize = 18f * template.fontScale

        bodyTextPaint.color = textColor
        bodyTextPaint.textSize = 17f * template.fontScale

        dotPaint.color = borderColor
    }

    /**
     * دالة رسم الإطار الخارجي وفق القالب (مزدوج أو مفرد)
     */
    protected open fun drawA4Borders(canvas: Canvas) {
        val margin = activeTemplate.marginDp.coerceAtLeast(20f)
        val outerRect = RectF(margin, margin, A4_WIDTH - margin, A4_HEIGHT - margin)

        canvas.drawRoundRect(outerRect, 12f, 12f, framePaint)

        if (activeTemplate.isDoubleFrame) {
            val innerMargin = margin + 6f
            val innerRect = RectF(innerMargin, innerMargin, A4_WIDTH - innerMargin, A4_HEIGHT - innerMargin)
            canvas.drawRoundRect(innerRect, 10f, 10f, innerFramePaint)
        }
    }

    /**
     * رسم رقم الصفحة والتذييل السفلي
     */
    protected open fun drawFooterPageNumber(canvas: Canvas) {
        val footerPaint = Paint().apply {
            color = try { Color.parseColor(activeTemplate.borderColorHex) } catch (e: Exception) { COLOR_BORDER }
            textSize = 14f * activeTemplate.fontScale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val footerY = A4_HEIGHT - (activeTemplate.marginDp / 2f).coerceAtLeast(15f)
        canvas.drawText("صفحة 1 من 1  •  عقد موثق قانونياً", A4_WIDTH / 2f, footerY, footerPaint)
    }

    /**
     * دالة مجردة (Abstract) تحتوي على خطوات رسم محتوى العقد المحدد
     */
    protected abstract fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    )

    /**
     * رسم نص RTL مع ضبط دقيق يمنع الخروج عن الشاشة أو التداخل، مع التفاف تلقائي للأسطر عند الحاجة
     */
    protected fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint = valuePaint,
        align: Paint.Align = Paint.Align.RIGHT,
        maxLines: Int = 3,
        lineSpacingMultiplier: Float = 1.35f
    ) {
        if (text.isEmpty() || maxWidth <= 0f) return

        val originalSize = paint.textSize
        val currentPaint = Paint(paint).apply { textAlign = align }

        var measureWidth = currentPaint.measureText(text)
        val minTextSize = (originalSize * 0.72f).coerceAtLeast(11f)

        // 1. تقليص التكبير تدريجياً حتى يستوعب العرض
        while (measureWidth > maxWidth && currentPaint.textSize > minTextSize) {
            currentPaint.textSize -= 0.5f
            measureWidth = currentPaint.measureText(text)
        }

        // 2. إذا كان النص لا يزال أطول من المساحة المتاحة، يتم تقسيمه على أسطر متعددة (Word Wrap)
        if (currentPaint.measureText(text) > maxWidth) {
            val words = text.split(" ")
            val lines = mutableListOf<String>()
            var currentLine = ""

            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (currentPaint.measureText(testLine) <= maxWidth) {
                    currentLine = testLine
                } else {
                    if (currentLine.isNotEmpty()) lines.add(currentLine)
                    currentLine = word
                }
                if (lines.size >= maxLines - 1) break
            }
            if (currentLine.isNotEmpty() && lines.size < maxLines) {
                lines.add(currentLine)
            }

            var currentY = y
            val lineStep = currentPaint.textSize * lineSpacingMultiplier
            for (line in lines) {
                canvas.drawText(line, x, currentY, currentPaint)
                currentY += lineStep
            }
        } else {
            canvas.drawText(text, x, y, currentPaint)
        }

        paint.textSize = originalSize // إعادة تعيين الحجم الأصلي
    }

    /**
     * رسم حقل نصي يتضمن عنواناً ونصف فارغ منقوطاً مع قيمة النص فوق النقاط
     */
    protected fun drawFieldWithDots(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        labelWidth: Float = 0f
    ) {
        // 1. رسم عنوان الحقل
        var currentX = x
        if (label.isNotEmpty()) {
            labelPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(label, currentX, y, labelPaint)
            val computedLabelWidth = if (labelWidth > 0f) labelWidth else labelPaint.measureText(label) + 10f
            currentX -= computedLabelWidth
        }

        val dotSpaceWidth = (currentX - (x - totalWidth)).coerceAtLeast(30f)

        // 2. إذا كان القيمة فارغة: رسم نقاط إكمال
        if (value.isBlank()) {
            val dots = buildString {
                repeat((dotSpaceWidth / 7f).toInt().coerceAtLeast(4)) { append(".") }
            }
            dotPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(dots, currentX, y, dotPaint)
        } else {
            // 3. رسم القيمة المدخلة مع تقليص تلقائي عند زيادة الطول
            drawRtlText(
                canvas = canvas,
                text = value,
                x = currentX,
                y = y,
                maxWidth = dotSpaceWidth,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        }
    }

    /**
     * رسم مربعين متجاورين (الطرف الأول البائع - الطرف الثاني المشتري) بتصميم رسمي فاخر
     */
    protected fun drawSideBySidePartyBoxes(
        canvas: Canvas,
        topY: Float,
        boxHeight: Float,
        rightTitle: String,
        leftTitle: String
    ): Pair<RectF, RectF> {
        val margin = 50f
        val boxWidth = (A4_WIDTH - (margin * 2) - 30f) / 2f

        val rightBox = RectF(A4_WIDTH - margin - boxWidth, topY, A4_WIDTH - margin, topY + boxHeight)
        val leftBox = RectF(margin, topY, margin + boxWidth, topY + boxHeight)

        val bgPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val borderPaint = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val headerBgPaint = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val headerHeight = 36f

        // رسم المربع الأيمن
        canvas.drawRoundRect(rightBox, 10f, 10f, bgPaint)
        val rightHeaderRect = RectF(rightBox.left, rightBox.top, rightBox.right, rightBox.top + headerHeight)
        val rightPath = Path().apply {
            addRoundRect(rightHeaderRect, floatArrayOf(10f, 10f, 10f, 10f, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }
        canvas.drawPath(rightPath, headerBgPaint)
        canvas.drawRoundRect(rightBox, 10f, 10f, borderPaint)

        // رسم المربع الأيسر
        canvas.drawRoundRect(leftBox, 10f, 10f, bgPaint)
        val leftHeaderRect = RectF(leftBox.left, leftBox.top, leftBox.right, leftBox.top + headerHeight)
        val leftPath = Path().apply {
            addRoundRect(leftHeaderRect, floatArrayOf(10f, 10f, 10f, 10f, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }
        canvas.drawPath(leftPath, headerBgPaint)
        canvas.drawRoundRect(leftBox, 10f, 10f, borderPaint)

        // رسم عناوين المربعين بالنص الأبيض الناصع
        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(rightTitle, rightBox.centerX(), topY + 25f, headerPaint)
        canvas.drawText(leftTitle, leftBox.centerX(), topY + 25f, headerPaint)

        return Pair(rightBox, leftBox)
    }

    /**
     * رسم صورة هيدر اختيارية بأمان، إذا لم توجد يتم تجاهلها دون أخطاء أو فراغات.
     */
    protected fun drawOptionalHeaderImage(
        canvas: Canvas,
        context: Context?,
        assetOrDrawableName: String,
        destRect: RectF
    ) {
        if (context == null) return
        try {
            // محاولة تحميل الصورة من drawables
            val resId = context.resources.getIdentifier(assetOrDrawableName, "drawable", context.packageName)
            if (resId != 0) {
                val bitmap = BitmapFactory.decodeResource(context.resources, resId)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    return
                }
            }

            // محاولة تحميل الصورة من assets
            val inputStream = context.assets.open(assetOrDrawableName)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap != null) {
                canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        } catch (_: Exception) {
            // تجاهل أي خطأ بهدوء وبدون أي تأثير على الرسم
        }
    }

    /**
     * رسم التواقيع أسفل العقد بالتوزيع المتساوي
     */
    protected fun drawSignatures(
        canvas: Canvas,
        titles: List<String>,
        bottomY: Float = A4_HEIGHT - 185f
    ) {
        val margin = 50f
        val totalWidth = A4_WIDTH - (margin * 2)
        val colWidth = totalWidth / titles.size.coerceAtLeast(1)

        val sigPaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val dotLinePaint = Paint().apply {
            color = COLOR_BORDER
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        for (i in titles.indices) {
            val centerX = A4_WIDTH - margin - (i * colWidth) - (colWidth / 2f)
            canvas.drawText("...........................", centerX, bottomY - 25f, dotLinePaint)
            canvas.drawText(titles[i], centerX, bottomY, sigPaint)
        }
    }
}
