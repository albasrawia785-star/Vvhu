package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MotorcycleContract
import com.example.ClearableOutlinedTextField

/**
 * واجهة إدخال بيانات عقد بيع وشراء الدراجات والتكتك والستوتات
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MotorcycleFormUi(
    contract: MotorcycleContract,
    onContractChange: ((MotorcycleContract) -> MotorcycleContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // الهيدر ورقم الوصل
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.TwoWheeler,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "عقد بيع دراجة / تكتك",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "نموذج معتمد رسمياً A4",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                ClearableOutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { value -> onContractChange { it.copy(contractNo = value) } },
                    label = { Text("رقم الوصل") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_motorcycle_contract_no"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next)
                )
            }
        }

        // الطرف الأول ( البائع )
        FormSectionCard(
            title = "بيانات الطرف الأول ( البائع )",
            icon = Icons.Default.Person
        ) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { valStr -> onContractChange { it.copy(sellerName = valStr) } },
                label = { Text("اسم البائع الثلاثي") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_name"),
                maxLines = 2,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { valStr -> onContractChange { it.copy(sellerAddress = valStr) } },
                label = { Text("عنوان السكن") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_address"),
                maxLines = 3,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.sellerNeighborhood,
                onValueChange = { valStr -> onContractChange { it.copy(sellerNeighborhood = valStr) } },
                label = { Text("المحلة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_neighborhood"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.sellerAlley,
                onValueChange = { valStr -> onContractChange { it.copy(sellerAlley = valStr) } },
                label = { Text("الزقاق") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_alley"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.sellerHouse,
                onValueChange = { valStr -> onContractChange { it.copy(sellerHouse = valStr) } },
                label = { Text("الدار") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_house"),
                singleLine = true
            )

            val sellerIdError = com.example.ContractValidation.validateNationalId(contract.sellerIdNumber, "بطاقة البائع")
            val sellerPhoneError = com.example.ContractValidation.validatePhone(contract.sellerPhone, "هاتف البائع")

            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { valStr -> onContractChange { it.copy(sellerIdNumber = valStr) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = sellerIdError != null,
                supportingText = sellerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_id"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { valStr -> onContractChange { it.copy(sellerPhone = valStr) } },
                label = { Text("رقم الهاتف (11 رقم)") },
                isError = sellerPhoneError != null,
                supportingText = sellerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_seller_phone"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
        }

        // الطرف الثاني ( المشتري )
        FormSectionCard(
            title = "بيانات الطرف الثاني ( المشتري )",
            icon = Icons.Default.PersonOutline
        ) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { valStr -> onContractChange { it.copy(buyerName = valStr) } },
                label = { Text("اسم المشتري الثلاثي") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_name"),
                maxLines = 2,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { valStr -> onContractChange { it.copy(buyerAddress = valStr) } },
                label = { Text("عنوان السكن") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_address"),
                maxLines = 3,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.buyerNeighborhood,
                onValueChange = { valStr -> onContractChange { it.copy(buyerNeighborhood = valStr) } },
                label = { Text("المحلة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_neighborhood"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.buyerAlley,
                onValueChange = { valStr -> onContractChange { it.copy(buyerAlley = valStr) } },
                label = { Text("الزقاق") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_alley"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.buyerHouse,
                onValueChange = { valStr -> onContractChange { it.copy(buyerHouse = valStr) } },
                label = { Text("الدار") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_house"),
                singleLine = true
            )

            val buyerIdError = com.example.ContractValidation.validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")
            val buyerPhoneError = com.example.ContractValidation.validatePhone(contract.buyerPhone, "هاتف المشتري")

            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { valStr -> onContractChange { it.copy(buyerIdNumber = valStr) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = buyerIdError != null,
                supportingText = buyerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_id"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { valStr -> onContractChange { it.copy(buyerPhone = valStr) } },
                label = { Text("رقم الهاتف (11 رقم)") },
                isError = buyerPhoneError != null,
                supportingText = buyerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_buyer_phone"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
        }

        // مواصفات المركبة / الدراجة
        FormSectionCard(
            title = "مواصفات المركبة / الدراجة / الستوتة",
            icon = Icons.Default.TwoWheeler
        ) {
            var vehicleTypeExpanded by remember { mutableStateOf(false) }
            val vehicleTypeOptions = remember { listOf("تكتك", "ستوتة", "دراجة نارية") }

            ClearableOutlinedTextField(
                value = contract.registeredNumber,
                onValueChange = { valStr -> onContractChange { it.copy(registeredNumber = valStr) } },
                label = { Text("الدراجة المرقمة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_registered_num"),
                singleLine = true
            )

            ExposedDropdownMenuBox(
                expanded = vehicleTypeExpanded,
                onExpandedChange = { vehicleTypeExpanded = !vehicleTypeExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                ClearableOutlinedTextField(
                    value = contract.vehicleType,
                    onValueChange = { valStr -> onContractChange { it.copy(vehicleType = valStr) } },
                    label = { Text("نوع المركبة") },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.example.ClearIconButton(value = contract.vehicleType, onClear = { onContractChange { it.copy(vehicleType = "") } })
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = vehicleTypeExpanded)
                        }
                    },
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                        .testTag("input_motorcycle_vehicle_type"),
                    singleLine = true
                )
                ExposedDropdownMenu(
                    expanded = vehicleTypeExpanded,
                    onDismissRequest = { vehicleTypeExpanded = false }
                ) {
                    vehicleTypeOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                onContractChange { it.copy(vehicleType = option) }
                                vehicleTypeExpanded = false
                            }
                        )
                    }
                }
            }

            ClearableOutlinedTextField(
                value = contract.brand,
                onValueChange = { valStr -> onContractChange { it.copy(brand = valStr) } },
                label = { Text("الماركة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_brand"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.color,
                onValueChange = { valStr -> onContractChange { it.copy(color = valStr) } },
                label = { Text("اللون") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_color"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.engineCc,
                onValueChange = { valStr -> onContractChange { it.copy(engineCc = valStr) } },
                label = { Text("الحجم") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_engine_cc"),
                singleLine = true
            )

            ClearableOutlinedTextField(
                value = contract.engineNumber,
                onValueChange = { valStr -> onContractChange { it.copy(engineNumber = valStr) } },
                label = { Text("رقم المحرك") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_engine_no"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.chassisNumber,
                onValueChange = { valStr -> onContractChange { it.copy(chassisNumber = valStr) } },
                label = { Text("رقم الشاسي") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_chassis_no"),
                singleLine = true
            )
        }

        // المبالغ المالية
        FormSectionCard(
            title = "المبالغ المالية والدفع",
            icon = Icons.Default.AttachMoney
        ) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { valStr -> onContractChange { it.copy(totalPrice = valStr) } },
                label = { Text("ببدل قدره (السعر الكلي بالأرقام)") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_total_price"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { valStr -> onContractChange { it.copy(totalPriceWords = valStr) } },
                label = { Text("المبلغ كتابةً (مثال: مليون وثمانمائة ألف دينار)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_price_words"),
                maxLines = 3,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.paidAmount,
                onValueChange = { valStr -> onContractChange { it.copy(paidAmount = valStr) } },
                label = { Text("قبض البائع مبلغ (المقبوض)") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_paid_amount"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.remainingAmount,
                onValueChange = { valStr -> onContractChange { it.copy(remainingAmount = valStr) } },
                label = { Text("والباقي (المتبقي)") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_remaining_amount"),
                singleLine = true
            )
        }

        // بيانات البائع الحائز
        FormSectionCard(
            title = "بيانات البائع الحائز",
            icon = Icons.Default.AssignmentInd
        ) {
            ClearableOutlinedTextField(
                value = contract.possessorName,
                onValueChange = { valStr -> onContractChange { it.copy(possessorName = valStr) } },
                label = { Text("اسم البائع الحائز") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_name"),
                maxLines = 2,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.possessorAddress,
                onValueChange = { valStr -> onContractChange { it.copy(possessorAddress = valStr) } },
                label = { Text("عنوان السكن") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_address"),
                maxLines = 3,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.possessorNeighborhood,
                onValueChange = { valStr -> onContractChange { it.copy(possessorNeighborhood = valStr) } },
                label = { Text("المحلة") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_neighborhood"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.possessorAlley,
                onValueChange = { valStr -> onContractChange { it.copy(possessorAlley = valStr) } },
                label = { Text("الزقاق") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_alley"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.possessorHouse,
                onValueChange = { valStr -> onContractChange { it.copy(possessorHouse = valStr) } },
                label = { Text("الدار") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_house"),
                singleLine = true
            )

            ClearableOutlinedTextField(
                value = contract.possessorIdNumber,
                onValueChange = { valStr -> onContractChange { it.copy(possessorIdNumber = valStr) } },
                label = { Text("رقم الهوية وجهة الإصدار") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_id"),
                singleLine = true
            )
            ClearableOutlinedTextField(
                value = contract.possessorPhone,
                onValueChange = { valStr -> onContractChange { it.copy(possessorPhone = valStr) } },
                label = { Text("رقم الهاتف") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_possessor_phone"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
        }

        // الملاحظات والتاريخ
        FormSectionCard(
            title = "الملاحظات والتاريخ والوقت",
            icon = Icons.Default.Notes
        ) {
            ClearableOutlinedTextField(
                value = contract.notes,
                onValueChange = { valStr -> onContractChange { it.copy(notes = valStr) } },
                label = { Text("الملاحظات") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_notes"),
                minLines = 2,
                maxLines = 5
            )
            com.example.DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { valStr -> onContractChange { it.copy(contractDate = valStr) } },
                label = "تاريخ العقد",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_motorcycle_date"
            )
            ClearableOutlinedTextField(
                value = contract.contractTime,
                onValueChange = { valStr -> onContractChange { it.copy(contractTime = valStr) } },
                label = { Text("الساعة / الوقت") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_time"),
                singleLine = true
            )

            val w1Val = if (contract.witness1Name.isNotBlank()) contract.witness1Name else contract.witnessName
            ClearableOutlinedTextField(
                value = w1Val,
                onValueChange = { valStr -> onContractChange { it.copy(witness1Name = valStr, witnessName = valStr) } },
                label = { Text("اسم الشاهد الأول") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_witness1_name"),
                maxLines = 2,
                minLines = 1
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { valStr -> onContractChange { it.copy(witness2Name = valStr) } },
                label = { Text("اسم الشاهد الثاني") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_motorcycle_witness2_name"),
                maxLines = 2,
                minLines = 1
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun FormSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                content()
            }
        }
    }
}
