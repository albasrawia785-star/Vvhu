package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.PrinterState

/**
 * الواجهة الرئيسية المطابقة بالكامل للتصميم المرفق (عقود برو)
 */
@Composable
fun HomeScreenUi(
    onSelectRealEstate: () -> Unit,
    onSelectCarSale: () -> Unit,
    onSelectRental: () -> Unit,
    onSelectMotorcycle: () -> Unit,
    onSelectSavedContracts: () -> Unit,
    onSelectPrinter: () -> Unit,
    onSelectSettings: () -> Unit,
    onSelectContractTemplates: () -> Unit = {},
    onMenuClick: () -> Unit = {},
    onNotificationClick: () -> Unit = {},
    savedContractsCount: Int = 0,
    printerState: PrinterState = PrinterState.Idle
) {
    val pageBg = Color(0xFFF7F9FC)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBg)
    ) {
        // خلفية الفن الجرافيكي والمنحنيات المنقطة والموجات الزرقاء
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. الشكل الأزرق العضوي بأعلى اليسار
            val topLeftPath = Path().apply {
                moveTo(0f, 0f)
                lineTo(w * 0.38f, 0f)
                cubicTo(
                    w * 0.32f, h * 0.07f,
                    w * 0.18f, h * 0.11f,
                    0f, h * 0.13f
                )
                close()
            }
            drawPath(path = topLeftPath, color = Color(0xFF1E65FF))

            // شبكة النقاط بأعلى اليسار
            val dotRadius = 2.5.dp.toPx()
            val dotColor = Color(0xFFCBD5E1)
            val startX = w * 0.22f
            val startY = h * 0.04f
            val spacingX = 11.dp.toPx()
            val spacingY = 11.dp.toPx()
            for (row in 0 until 4) {
                for (col in 0 until 4) {
                    drawCircle(
                        color = dotColor,
                        radius = dotRadius,
                        center = Offset(startX + col * spacingX, startY + row * spacingY)
                    )
                }
            }

            // 2. الدائرة الزرقاء الشفافة بالجهة اليمنى العليا
            drawCircle(
                color = Color(0xFF1E65FF).copy(alpha = 0.08f),
                radius = w * 0.38f,
                center = Offset(w * 0.98f, h * 0.18f)
            )

            // 3. الشكل الأزرق العضوي بأسفل اليمين
            val bottomRightPath = Path().apply {
                moveTo(w, h)
                lineTo(w * 0.62f, h)
                cubicTo(
                    w * 0.72f, h * 0.94f,
                    w * 0.85f, h * 0.92f,
                    w, h * 0.91f
                )
                close()
            }
            drawPath(path = bottomRightPath, color = Color(0xFF1E65FF))

            // شبكة النقاط بأسفل اليمين
            val bStartX = w * 0.88f
            val bStartY = h * 0.85f
            for (row in 0 until 4) {
                for (col in 0 until 3) {
                    drawCircle(
                        color = dotColor,
                        radius = dotRadius,
                        center = Offset(bStartX + col * spacingX, bStartY + row * spacingY)
                    )
                }
            }

            // 4. خطوط الموجات الفاتحة بأسفل اليسار
            val wavePath1 = Path().apply {
                moveTo(0f, h * 0.80f)
                cubicTo(
                    w * 0.25f, h * 0.78f,
                    w * 0.40f, h * 0.93f,
                    w * 0.80f, h * 0.96f
                )
            }
            drawPath(
                path = wavePath1,
                color = Color(0xFF1E65FF).copy(alpha = 0.12f),
                style = Stroke(width = 1.5.dp.toPx())
            )

            val wavePath2 = Path().apply {
                moveTo(0f, h * 0.84f)
                cubicTo(
                    w * 0.20f, h * 0.82f,
                    w * 0.35f, h * 0.95f,
                    w * 0.70f, h * 0.97f
                )
            }
            drawPath(
                path = wavePath2,
                color = Color(0xFF1E65FF).copy(alpha = 0.08f),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Top Title & Branding Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "الرئيسية",
                    color = Color(0xFF0F172A),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "مرحبا بك في",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF64748B)
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "عقود ",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "برو",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF1E65FF)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFF1E65FF))
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "اختر نوع العقد",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // مؤشر حالة اتصال البلوتوث بالطابعة
            BluetoothStatusIndicatorCard(
                printerState = printerState,
                onClick = onSelectPrinter
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2x2 Flexible Contract Cards Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // الصف الأول
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // عقد بيع عقار (أزرق)
                    ContractGridCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("card_real_estate"),
                        title = "عقد بيع عقار",
                        icon = Icons.Default.HomeWork,
                        textColor = Color(0xFF1E65FF),
                        bgColor = Color(0xFFF0F5FE),
                        borderColor = Color(0xFFD6E4FF),
                        onClick = onSelectRealEstate
                    )

                    // عقد بيع سيارة (أخضر)
                    ContractGridCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("card_car_sale"),
                        title = "عقد بيع سيارة",
                        icon = Icons.Default.DirectionsCar,
                        textColor = Color(0xFF00A86B),
                        bgColor = Color(0xFFEEFAF4),
                        borderColor = Color(0xFFD1F3E0),
                        onClick = onSelectCarSale
                    )
                }

                // الصف الثاني
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // عقد إيجار (بنفسجي)
                    ContractGridCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("card_rental"),
                        title = "عقد إيجار",
                        icon = Icons.Default.Apartment,
                        textColor = Color(0xFF6366F1),
                        bgColor = Color(0xFFF3F2FE),
                        borderColor = Color(0xFFE0E0FE),
                        onClick = onSelectRental
                    )

                    // عقد دراجة / تك تك / ستوتة (داكن / كحلي)
                    ContractGridCard(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("card_motorcycle"),
                        title = "عقد دراجة / تك تك / ستوتة",
                        icon = Icons.Default.TwoWheeler,
                        textColor = Color(0xFF1E293B),
                        bgColor = Color(0xFFF1F5F9),
                        borderColor = Color(0xFFE2E8F0),
                        onClick = onSelectMotorcycle
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Floating Action Bar Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 6.dp,
                        shape = RoundedCornerShape(24.dp),
                        spotColor = Color.Black.copy(alpha = 0.08f)
                    ),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // الإعدادات
                    BottomActionItem(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_settings"),
                        title = "الإعدادات",
                        icon = Icons.Default.Settings,
                        iconTint = Color(0xFF475569),
                        badgeBgColor = Color(0xFFF1F5F9),
                        onClick = onSelectSettings
                    )

                    VerticalDivider(
                        modifier = Modifier
                            .height(32.dp)
                            .width(1.dp),
                        color = Color(0xFFE2E8F0)
                    )

                    // الطباعة
                    val printerDotColor = when (printerState) {
                        is PrinterState.Success -> Color(0xFF10B981)
                        is PrinterState.Connecting, is PrinterState.Printing, is PrinterState.Scanning -> Color(0xFFF59E0B)
                        is PrinterState.Error -> Color(0xFFEF4444)
                        else -> Color(0xFF94A3B8)
                    }

                    BottomActionItem(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_printer"),
                        title = "الطباعة",
                        icon = Icons.Default.Print,
                        iconTint = Color(0xFF1E65FF),
                        badgeBgColor = Color(0xFFEFF6FF),
                        statusDotColor = printerDotColor,
                        onClick = onSelectPrinter
                    )

                    VerticalDivider(
                        modifier = Modifier
                            .height(32.dp)
                            .width(1.dp),
                        color = Color(0xFFE2E8F0)
                    )

                    // العقود المحفوظة
                    BottomActionItem(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_saved_contracts"),
                        title = "العقود المحفوظة",
                        icon = Icons.Default.Article,
                        iconTint = Color(0xFF7C3AED),
                        badgeBgColor = Color(0xFFF3F0FF),
                        onClick = onSelectSavedContracts
                    )
                }
            }
        }
    }
}

/**
 * كارت العقد الفرعي في الشبكة 2x2 مع الأيقونة العائمة
 */
@Composable
private fun ContractGridCard(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    textColor: Color,
    bgColor: Color,
    borderColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = textColor.copy(alpha = 0.15f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(10.dp)
        ) {
            // White circular floating badge for the icon
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .shadow(
                        elevation = 4.dp,
                        shape = CircleShape,
                        spotColor = textColor.copy(alpha = 0.2f)
                    )
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = textColor,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                color = textColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Accent bar under text
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(textColor)
            )
        }
    }
}

/**
 * عنصر أداة في الشريط العائم السفلي
 */
@Composable
private fun BottomActionItem(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    iconTint: Color,
    badgeBgColor: Color,
    statusDotColor: Color? = null,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(badgeBgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
            if (statusDotColor != null) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .align(Alignment.TopEnd)
                        .background(statusDotColor, CircleShape)
                        .border(1.dp, Color.White, CircleShape)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title,
            color = Color(0xFF334155),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

private data class StatusInfo(
    val title: String,
    val subtitle: String,
    val color: Color,
    val bgColor: Color,
    val icon: ImageVector
)

/**
 * بطاقة مؤشر حالة اتصال البلوتوث بالطابعة المباشرة
 */
@Composable
fun BluetoothStatusIndicatorCard(
    printerState: PrinterState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val info = when (printerState) {
        is PrinterState.Idle -> StatusInfo(
            title = "حالة الطابعة: غير متصلة ⚪",
            subtitle = "انقر لاختيار والاتصال بطابعة A4 البلوتوث",
            color = Color(0xFF64748B),
            bgColor = Color(0xFFF1F5F9),
            icon = Icons.Default.Bluetooth
        )
        is PrinterState.Scanning -> StatusInfo(
            title = "حالة الطابعة: جاري البحث... 🔍",
            subtitle = "جاري البحث عن أجهزة البلوتوث المتاحة في النطاق",
            color = Color(0xFF2563EB),
            bgColor = Color(0xFFEFF6FF),
            icon = Icons.Default.BluetoothSearching
        )
        is PrinterState.Connecting -> StatusInfo(
            title = "حالة الطابعة: جاري الاتصال... 🟡",
            subtitle = "جاري الاتصال بـ ${printerState.deviceName}",
            color = Color(0xFFD97706),
            bgColor = Color(0xFFFEF3C7),
            icon = Icons.Default.BluetoothSearching
        )
        is PrinterState.Printing -> StatusInfo(
            title = "حالة الطابعة: جاري الطباعة (${printerState.progress}%) 🖨️",
            subtitle = "جاري إرسال بيانات العقد إلى الطابعة المباشرة",
            color = Color(0xFF059669),
            bgColor = Color(0xFFD1FAE5),
            icon = Icons.Default.Print
        )
        is PrinterState.Success -> StatusInfo(
            title = "حالة الطابعة: متصلة وجاهزة 🟢",
            subtitle = printerState.message,
            color = Color(0xFF059669),
            bgColor = Color(0xFFD1FAE5),
            icon = Icons.Default.BluetoothConnected
        )
        is PrinterState.Error -> StatusInfo(
            title = "حالة الطابعة: تعذر الاتصال 🔴",
            subtitle = printerState.errorMessage,
            color = Color(0xFFDC2626),
            bgColor = Color(0xFFFEE2E2),
            icon = Icons.Default.BluetoothDisabled
        )
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("bluetooth_status_card"),
        shape = RoundedCornerShape(16.dp),
        color = info.bgColor,
        border = BorderStroke(1.dp, info.color.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // أيقونة البلوتوث مع شارة ملونة
                Box(contentAlignment = Alignment.Center) {
                    Surface(
                        shape = CircleShape,
                        color = info.color.copy(alpha = 0.15f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = info.icon,
                                contentDescription = null,
                                tint = info.color,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    // مؤشر النقطة الملونة
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .align(Alignment.TopStart)
                            .background(info.color, CircleShape)
                            .border(1.5.dp, Color.White, CircleShape)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = info.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = info.subtitle,
                        fontSize = 11.sp,
                        color = Color(0xFF475569),
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // زر الحركة الفوري
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                border = BorderStroke(1.dp, info.color.copy(alpha = 0.5f))
            ) {
                Text(
                    text = if (printerState is PrinterState.Success) "جاهز للطباعة" else "فحص / اتصال",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = info.color,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

