package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.CarSaleContract
import com.example.CarSaleContractRenderer
import com.example.ClearableOutlinedTextField
import com.example.ContractTemplate
import com.example.ContractTemplateLibrary
import com.example.OfficeInfo
import com.example.TemplateCategory
import com.example.TemplateCustomizationOptions
import com.example.TemplateSettingsManager

/**
 * شاشة إدارة وتصميم قوالب العقود (20+ قالب احترافي)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContractTemplatesScreen(
    onBack: () -> Unit,
    onTemplateChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    val templateManager = remember { TemplateSettingsManager.getInstance(context) }

    var selectedCategory by remember { mutableStateOf(TemplateCategory.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf(0) } // 0: القوالب, 1: التخصيص

    var currentActiveTemplateId by remember { mutableStateOf(templateManager.selectedTemplateId) }
    var customizationOptions by remember { mutableStateOf(templateManager.getCustomizationOptions()) }

    var previewTemplate by remember { mutableStateOf<ContractTemplate?>(null) }
    var showResetOriginalDialog by remember { mutableStateOf(false) }
    var showResetCustomizationDialog by remember { mutableStateOf(false) }

    val allTemplates = remember { ContractTemplateLibrary.templates }

    val filteredTemplates = remember(searchQuery, selectedCategory, currentActiveTemplateId) {
        allTemplates.filter { template ->
            val matchesCategory = (selectedCategory == TemplateCategory.ALL) || (template.category == selectedCategory)
            val matchesQuery = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim()
                template.nameAr.contains(q, ignoreCase = true) ||
                template.descriptionAr.contains(q, ignoreCase = true)
            }
            matchesCategory && matchesQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "مكتبة وقوالب العقود",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("templates_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // زر العودة إلى التصميم الأصلي
                    OutlinedButton(
                        onClick = { showResetOriginalDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.padding(end = 8.dp).testTag("btn_reset_to_original")
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("التصميم الأصلي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F2D59))
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // شريط التنقل بين علامات التبويب (القوالب / التخصيص)
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.White,
                contentColor = Color(0xFF0F2D59)
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.GridView, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("مكتبة القوالب (${allTemplates.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_templates_library")
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("خيارات التخصيص", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_customization")
                )
            }

            if (activeTab == 0) {
                // قسم مكتبة القوالب
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    // حقل البحث
                    ClearableOutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("search_templates_input"),
                        placeholder = { Text("بحث باسم القالب أو المواصفات...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        shape = RoundedCornerShape(12.dp)
                    )

                    // شرائح التصنيفات (Filter Chips)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    ) {
                        items(TemplateCategory.entries.toTypedArray()) { category ->
                            val isSelected = selectedCategory == category
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = category },
                                label = { Text(category.titleAr, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0F2D59),
                                    selectedLabelColor = Color.White
                                ),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.testTag("filter_category_${category.name}")
                            )
                        }
                    }

                    // شبكة عرض القوالب
                    if (filteredTemplates.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("لم يتم العثور على قوالب تطابق البحث", color = Color.Gray, fontSize = 14.sp)
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize().weight(1f)
                        ) {
                            items(filteredTemplates, key = { it.id }) { template ->
                                TemplateCardItem(
                                    template = template,
                                    isActive = template.id == currentActiveTemplateId,
                                    onSelect = {
                                        templateManager.selectedTemplateId = template.id
                                        currentActiveTemplateId = template.id
                                        onTemplateChanged()
                                        Toast.makeText(context, "تم اختيار قالب \"${template.nameAr}\"", Toast.LENGTH_SHORT).show()
                                    },
                                    onPreview = {
                                        previewTemplate = template
                                    }
                                )
                            }
                        }
                    }
                }
            } else {
                // قسم خيارات التخصيص
                CustomizationPanel(
                    options = customizationOptions,
                    onOptionChange = { updated ->
                        customizationOptions = updated
                        templateManager.saveCustomizationOptions(updated)
                        onTemplateChanged()
                    },
                    onResetCustomization = {
                        showResetCustomizationDialog = true
                    }
                )
            }
        }
    }

    // Modal المعاينة الكاملة A4
    if (previewTemplate != null) {
        A4TemplatePreviewDialog(
            template = previewTemplate!!,
            onDismiss = { previewTemplate = null },
            onUseTemplate = {
                templateManager.selectedTemplateId = previewTemplate!!.id
                currentActiveTemplateId = previewTemplate!!.id
                onTemplateChanged()
                previewTemplate = null
                Toast.makeText(context, "تم تطبيق واستخدام القالب بنجاح!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // حوار تأكيد العودة للتصميم الأصلي
    if (showResetOriginalDialog) {
        AlertDialog(
            onDismissRequest = { showResetOriginalDialog = false },
            title = { Text("العودة إلى التصميم الأصلي؟", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Text(
                    "سيتم إلغاء القالب الحالي وتطبيق المظهر الافتراضي للتطبيق دون حذف أو مساس بأي بيانات أو عقود مخزنة.",
                    fontSize = 13.sp,
                    color = Color(0xFF334155)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        templateManager.resetToOriginalDesign()
                        currentActiveTemplateId = templateManager.selectedTemplateId
                        customizationOptions = templateManager.getCustomizationOptions()
                        onTemplateChanged()
                        showResetOriginalDialog = false
                        Toast.makeText(context, "تمت العودة إلى التصميم الأصلي للتطبيق!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text("نعم، العودة للأصلي", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetOriginalDialog = false }) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    // حوار تأكيد إعادة تعيين إعدادات التخصيص
    if (showResetCustomizationDialog) {
        AlertDialog(
            onDismissRequest = { showResetCustomizationDialog = false },
            title = { Text("إعادة تعيين تخصيصات القالب؟", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Text(
                    "سيتم إرجاع جميع ألوان الخطوط، الإطارات، الهوامش، والشعار إلى الوضع الافتراضي الخاص بالقالب المختار.",
                    fontSize = 13.sp,
                    color = Color(0xFF334155)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        templateManager.resetAllTemplateSettings()
                        customizationOptions = templateManager.getCustomizationOptions()
                        onTemplateChanged()
                        showResetCustomizationDialog = false
                        Toast.makeText(context, "تمت إعادة تعيين تخصيصات القالب بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F2D59))
                ) {
                    Text("إعادة التعيين", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetCustomizationDialog = false }) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * بطاقة عرض القالب في الشبكة
 */
@Composable
fun TemplateCardItem(
    template: ContractTemplate,
    isActive: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit
) {
    val context = LocalContext.current
    val primaryColor = try { Color(android.graphics.Color.parseColor(template.primaryColorHex)) } catch (e: Exception) { Color(0xFF0F172A) }
    val borderColor = try { Color(android.graphics.Color.parseColor(template.borderColorHex)) } catch (e: Exception) { Color(0xFF94A3B8) }

    val cardPreviewBitmap = remember(template) {
        val dummyContract = CarSaleContract(
            contractNo = "000101",
            galleryName = "معرض المبيعات النموذجي",
            sellerName = "محمد علي عبد الله",
            buyerName = "أحمد جاسم كريم",
            carBrandAndType = "تويوتا كامري",
            modelYear = "2024",
            annualRegNumber = "12345 / بغداد",
            color = "أبيض صدف",
            totalPrice = "35,000,000 دينار",
            totalPriceWords = "خمسة وثلاثون مليون دينار عراقي"
        )
        val renderer = CarSaleContractRenderer()
        renderer.renderBitmap(
            contractData = dummyContract,
            officeInfo = OfficeInfo("مكتب النبلاء", "07701234567", "البصرة"),
            context = context,
            overrideTemplate = template
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (isActive) 2.5.dp else 1.dp,
                color = if (isActive) Color(0xFF1E65FF) else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("template_card_${template.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isActive) 4.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Thumbnail معاينة مصغرة حقيقية لـ A4
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                    .clickable { onPreview() }
                    .padding(2.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Image(
                    bitmap = cardPreviewBitmap.asImageBitmap(),
                    contentDescription = template.nameAr,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(6.dp))
                )

                if (isActive) {
                    Surface(
                        color = Color(0xFF10B981),
                        shape = CircleShape,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(4.dp)
                            .size(20.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = template.nameAr,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = template.descriptionAr,
                fontSize = 10.sp,
                color = Color(0xFF64748B),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 13.sp,
                modifier = Modifier.height(28.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedButton(
                    onClick = onPreview,
                    modifier = Modifier.weight(1f).height(32.dp).testTag("btn_preview_${template.id}"),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text("معاينة A4", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                }

                Button(
                    onClick = onSelect,
                    modifier = Modifier.weight(1f).height(32.dp).testTag("btn_select_${template.id}"),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isActive) Color(0xFF10B981) else Color(0xFF0F2D59)
                    )
                ) {
                    Text(
                        text = if (isActive) "نشط كافتراضي" else "استخدام",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * حوار معاينة A4 تفاعلي للقالب
 */
@Composable
fun A4TemplatePreviewDialog(
    template: ContractTemplate,
    onDismiss: () -> Unit,
    onUseTemplate: () -> Unit
) {
    val context = LocalContext.current

    // توليد صورة العقد بالكامل باستخدام القالب المحدد
    val previewBitmap = remember(template) {
        val dummyContract = CarSaleContract(
            contractNo = "000101",
            galleryName = "معرض المبيعات النموذجي",
            sellerName = "محمد علي عبد الله",
            buyerName = "أحمد جاسم كريم",
            carBrandAndType = "تويوتا كامري",
            modelYear = "2024",
            annualRegNumber = "12345 / بغداد",
            color = "أبيض صدف",
            totalPrice = "35,000,000 دينار",
            totalPriceWords = "خمسة وثلاثون مليون دينار عراقي"
        )
        val renderer = CarSaleContractRenderer()
        renderer.renderBitmap(
            contractData = dummyContract,
            officeInfo = OfficeInfo("مكتب النبلاء للعقارات والسيارات", "07701234567", "البصرة"),
            context = context,
            overrideTemplate = template
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .testTag("a4_preview_dialog"),
            shape = RoundedCornerShape(18.dp),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                // شريط العنوان
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = Color(0xFF0F2D59))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "معاينة A4: ${template.nameAr}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F2D59)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // حاوية الصورة بالحجم الحقيقي لورقة A4
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "معاينة A4",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(8.dp))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // أزرار التحكم
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إغلاق المعاينة")
                    }

                    Button(
                        onClick = onUseTemplate,
                        modifier = Modifier.weight(1.2f).testTag("btn_confirm_use_template"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("استخدام هذا القالب", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * لوحة خيارات التخصيص الاحترافية (الألوان، الخطوط، الإطارات، والشعار)
 */
@Composable
fun CustomizationPanel(
    options: TemplateCustomizationOptions,
    onOptionChange: (TemplateCustomizationOptions) -> Unit,
    onResetCustomization: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "تخصيص القالب الحالي",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = Color(0xFF0F2D59)
        )

        // 1. خيارات الألوان
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("تخصيص الألوان الرئيسية", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F2D59))

                ColorPickerRow("لون الترويسة:", options.customHeaderColorHex ?: "#0F2D59") { newColor ->
                    onOptionChange(options.copy(customHeaderColorHex = newColor))
                }
                ColorPickerRow("لون العناوين:", options.customTitleColorHex ?: "#0F2D59") { newColor ->
                    onOptionChange(options.copy(customTitleColorHex = newColor))
                }
                ColorPickerRow("لون الإطار:", options.customFrameColorHex ?: "#94A3B8") { newColor ->
                    onOptionChange(options.copy(customFrameColorHex = newColor))
                }
                ColorPickerRow("لون النصوص:", options.customTextColorHex ?: "#0F172A") { newColor ->
                    onOptionChange(options.copy(customTextColorHex = newColor))
                }
            }
        }

        // 2. خيارات الأحجام والخطوط والسماكة
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("الأحجام والسماكة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F2D59))

                SliderOption("حجم الخط العام:", options.fontSizeScale, 0.8f, 1.2f) { newScale ->
                    onOptionChange(options.copy(fontSizeScale = newScale))
                }
                SliderOption("حجم ترويسة العنوان:", options.headerSizeScale, 0.8f, 1.3f) { newScale ->
                    onOptionChange(options.copy(headerSizeScale = newScale))
                }
                SliderOption("سماكة الإطار:", options.borderThicknessScale, 0.5f, 2.0f) { newScale ->
                    onOptionChange(options.copy(borderThicknessScale = newScale))
                }
            }
        }

        // 3. خيارات الإظهار والإخفاء
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("العناصر المرئية", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F2D59))

                ToggleOption("إظهار شعار المكتب", options.showLogo) {
                    onOptionChange(options.copy(showLogo = it))
                }
                ToggleOption("إظهار إطار العقد الخارجية", options.showFrame) {
                    onOptionChange(options.copy(showFrame = it))
                }
                ToggleOption("إظهار رقم الصفحة والتذييل", options.showPageNumber) {
                    onOptionChange(options.copy(showPageNumber = it))
                }
            }
        }

        // زر إعادة تعيين التخصيصات
        OutlinedButton(
            onClick = onResetCustomization,
            modifier = Modifier.fillMaxWidth().testTag("btn_reset_customizations"),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD32F2F)),
            border = BorderStroke(1.dp, Color(0xFFEF4444)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.RotateLeft, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("إعادة تعيين تخصيصات القالب للوضع الافتراضي", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ColorPickerRow(label: String, currentColorHex: String, onColorSelected: (String) -> Unit) {
    val presetColors = listOf("#0F2D59", "#1E65FF", "#047857", "#D4AF37", "#881337", "#18181B", "#000000")

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF334155))
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            presetColors.forEach { hex ->
                val color = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Black }
                val isSelected = currentColorHex.equals(hex, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) Color(0xFF1E65FF) else Color(0xFFCBD5E1),
                            shape = CircleShape
                        )
                        .clickable { onColorSelected(hex) }
                )
            }
        }
    }
}

@Composable
fun SliderOption(label: String, value: Float, min: Float, max: Float, onValueChange: (Float) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF334155))
            Text(text = "%.1fx".format(value), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F2D59))
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF0F2D59), activeTrackColor = Color(0xFF0F2D59))
        )
    }
}

@Composable
fun ToggleOption(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF334155))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
        )
    }
}
