package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.RentalContract
import com.example.ClearableOutlinedTextField
import com.example.FormSectionCard

@Composable
fun RentalFormUi(
    contract: RentalContract,
    onContractChange: ((RentalContract) -> RentalContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة رقم العقد والترويسة
        Surface(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Surface(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "عقد إيجار (A4)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                ClearableOutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { v -> onContractChange { it.copy(contractNo = v) } },
                    label = { Text("رقم العقد") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_rental_contract_no"),
                    textStyle = TextStyle(fontWeight = FontWeight.Bold)
                )
            }
        }

        // أطراف عقد الإيجار
        FormSectionCard(title = "أطراف العقد (المؤجر والمستأجر)", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sequenceNumber,
                onValueChange = { v -> onContractChange { it.copy(sequenceNumber = v) } },
                label = { Text("عدد التسلسل") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_seq")
            )
            ClearableOutlinedTextField(
                value = contract.doorsNumber,
                onValueChange = { v -> onContractChange { it.copy(doorsNumber = v) } },
                label = { Text("رقم الأبواب") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_doors")
            )
            ClearableOutlinedTextField(
                value = contract.lessorName,
                onValueChange = { v -> onContractChange { it.copy(lessorName = v) } },
                label = { Text("اسم المؤجر (صاحب الملك)") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_lessor_name")
            )
            ClearableOutlinedTextField(
                value = contract.lesseeName,
                onValueChange = { v -> onContractChange { it.copy(lesseeName = v) } },
                label = { Text("اسم المستأجر") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_lessee_name")
            )
        }

        // تفاصيل المأجور والمدة
        FormSectionCard(title = "عنوان المأجور والمدة", icon = Icons.Default.Key) {
            ClearableOutlinedTextField(
                value = contract.rentedPropertyDescription,
                onValueChange = { v -> onContractChange { it.copy(rentedPropertyDescription = v) } },
                label = { Text("وصف العقار المأجور (الرؤية والاطلاع على)") },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_rented_description")
            )

            ClearableOutlinedTextField(
                value = contract.propertyLocation,
                onValueChange = { v -> onContractChange { it.copy(propertyLocation = v) } },
                label = { Text("الواقع في المحلة") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_location")
            )
            ClearableOutlinedTextField(
                value = contract.alleyNumber,
                onValueChange = { v -> onContractChange { it.copy(alleyNumber = v) } },
                label = { Text("زقاق / دار") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_alley")
            )

            ClearableOutlinedTextField(
                value = contract.leaseDuration,
                onValueChange = { v -> onContractChange { it.copy(leaseDuration = v) } },
                label = { Text("مدة الإيجار (مثال: سنة واحدة)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_lease_duration")
            )

            com.example.DatePickerTextField(
                value = contract.startDate,
                onValueChange = { v -> onContractChange { it.copy(startDate = v) } },
                label = "ابتداءً من تاريخ",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_lease_start"
            )
            com.example.DatePickerTextField(
                value = contract.endDate,
                onValueChange = { v -> onContractChange { it.copy(endDate = v) } },
                label = "إلى نهاية تاريخ",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_lease_end"
            )
        }

        // الأجور والبدل
        FormSectionCard(title = "بدل الإيجار والتسديد", icon = Icons.Default.Money) {
            ClearableOutlinedTextField(
                value = contract.rentAmountWords,
                onValueChange = { v -> onContractChange { it.copy(rentAmountWords = v) } },
                label = { Text("بدل الإيجار كتابةً (مثال: خمسمائة ألف دينار شهرياً)") },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_rent_words")
            )

            ClearableOutlinedTextField(
                value = contract.rentAmountNumber,
                onValueChange = { v -> onContractChange { it.copy(rentAmountNumber = v) } },
                label = { Text("المبلغ بالأرقام أو كتابةً (دينار)") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_rent_number")
            )

            ClearableOutlinedTextField(
                value = contract.returnToLesseeText,
                onValueChange = { v -> onContractChange { it.copy(returnToLesseeText = v) } },
                label = { Text("العائد إلى المستأجر إليه ببدل إيجار...") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_return_to_lessee")
            )

            ClearableOutlinedTextField(
                value = contract.dwellingRightDetails,
                onValueChange = { v -> onContractChange { it.copy(dwellingRightDetails = v) } },
                label = { Text("حق السكن بـ...") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_dwelling_right")
            )
            ClearableOutlinedTextField(
                value = contract.dailyDelayFee,
                onValueChange = { v -> onContractChange { it.copy(dailyDelayFee = v) } },
                label = { Text("بدل غرامة التأخير اليومي") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_daily_delay")
            )

            ClearableOutlinedTextField(
                value = contract.propertyTaxOwner,
                onValueChange = { v -> onContractChange { it.copy(propertyTaxOwner = v) } },
                label = { Text("ضريبة الأملاك على المؤجر أو صاحب...") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_property_tax")
            )
        }

        // التاريخ والتوقيع والفقرات الإضافية
        FormSectionCard(title = "التاريخ والفقرات الإضافية والشهود", icon = Icons.Default.CalendarToday) {
            com.example.DatePickerTextField(
                value = contract.signDate,
                onValueChange = { v -> onContractChange { it.copy(signDate = v) } },
                label = "كتبت في تاريخ",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_rental_sign_date"
            )

            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { v -> onContractChange { it.copy(witness1Name = v) } },
                label = { Text("اسم الشاهد الأول") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_witness1")
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { v -> onContractChange { it.copy(witness2Name = v) } },
                label = { Text("اسم الشاهد الثاني") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_witness2")
            )

            ClearableOutlinedTextField(
                value = contract.additionalClauses,
                onValueChange = { v -> onContractChange { it.copy(additionalClauses = v) } },
                label = { Text("فقرات إضافية / شروط خاصة") },
                minLines = 2,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth().testTag("input_rental_additional_clauses")
            )
        }
    }
}
