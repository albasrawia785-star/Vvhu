package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.CarSaleContract
import com.example.ClearableOutlinedTextField
import com.example.FormSectionCard

@Composable
fun CarSaleFormUi(
    contract: CarSaleContract,
    onContractChange: ((CarSaleContract) -> CarSaleContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة ترويسة المعرض ورقم العقد
        Surface(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Surface(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "عقد بيع وشراء سيارة (معارض A4)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                ClearableOutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { v -> onContractChange { it.copy(contractNo = v) } },
                    label = { Text("رقم العقد") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_car_contract_no"),
                    textStyle = TextStyle(fontWeight = FontWeight.Bold)
                )
            }
        }

        // المالك الشرعي
        FormSectionCard(title = "المالك الشرعي للسيارة", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.carLegalOwner,
                onValueChange = { v -> onContractChange { it.copy(carLegalOwner = v) } },
                label = { Text("المالك الشرعي للسيارة") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_legal_owner")
            )
            ClearableOutlinedTextField(
                value = contract.ownerAddress,
                onValueChange = { v -> onContractChange { it.copy(ownerAddress = v) } },
                label = { Text("عنوانه") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_owner_address")
            )
        }

        // الطرف الأول (البائع)
        FormSectionCard(title = "الطرف الأول ( البائع )", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { v -> onContractChange { it.copy(sellerName = v) } },
                label = { Text("اسم البائع") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_seller_name")
            )

            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { v -> onContractChange { it.copy(sellerAddress = v) } },
                label = { Text("السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_seller_address")
            )

            val sellerPhoneError = com.example.ContractValidation.validatePhone(contract.sellerPhone, "هاتف البائع")
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { v -> onContractChange { it.copy(sellerPhone = v) } },
                label = { Text("الموبايل (11 رقم)") },
                isError = sellerPhoneError != null,
                supportingText = sellerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth().testTag("input_car_seller_phone")
            )

            val sellerIdError = com.example.ContractValidation.validateNationalId(contract.sellerIdNumber, "بطاقة البائع")
            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { v -> onContractChange { it.copy(sellerIdNumber = v) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = sellerIdError != null,
                supportingText = sellerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("input_car_seller_id")
            )
        }

        // الطرف الثاني (المشتري)
        FormSectionCard(title = "الطرف الثاني ( المشتري )", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { v -> onContractChange { it.copy(buyerName = v) } },
                label = { Text("اسم المشتري") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_name")
            )

            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { v -> onContractChange { it.copy(buyerAddress = v) } },
                label = { Text("السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_address")
            )

            val buyerPhoneError = com.example.ContractValidation.validatePhone(contract.buyerPhone, "هاتف المشتري")
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { v -> onContractChange { it.copy(buyerPhone = v) } },
                label = { Text("الموبايل (11 رقم)") },
                isError = buyerPhoneError != null,
                supportingText = buyerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_phone")
            )

            val buyerIdError = com.example.ContractValidation.validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")
            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { v -> onContractChange { it.copy(buyerIdNumber = v) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = buyerIdError != null,
                supportingText = buyerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("input_car_buyer_id")
            )
        }

        // مواصفات السيارة
        FormSectionCard(title = "مواصفات المركبة المباعة", icon = Icons.Default.DirectionsCar) {
            ClearableOutlinedTextField(
                value = contract.carCategory,
                onValueChange = { v -> onContractChange { it.copy(carCategory = v) } },
                label = { Text("الصنف (خصوصي/أجرة/حمل)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_category")
            )

            ClearableOutlinedTextField(
                value = contract.carBrandAndType,
                onValueChange = { v -> onContractChange { it.copy(carBrandAndType = v) } },
                label = { Text("نوع السيارة (تويوتا، هونداي...)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_brand")
            )

            ClearableOutlinedTextField(
                value = contract.modelYear,
                onValueChange = { v -> onContractChange { it.copy(modelYear = v) } },
                label = { Text("الموديل") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_model")
            )

            ClearableOutlinedTextField(
                value = contract.color,
                onValueChange = { v -> onContractChange { it.copy(color = v) } },
                label = { Text("اللون") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_color")
            )

            ClearableOutlinedTextField(
                value = contract.annualRegNumber,
                onValueChange = { v -> onContractChange { it.copy(annualRegNumber = v) } },
                label = { Text("رقم السنوية") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_reg_no")
            )

            ClearableOutlinedTextField(
                value = contract.engineNumber,
                onValueChange = { v -> onContractChange { it.copy(engineNumber = v) } },
                label = { Text("رقم المحرك") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_engine_no")
            )

            ClearableOutlinedTextField(
                value = contract.chassisNumber,
                onValueChange = { v -> onContractChange { it.copy(chassisNumber = v) } },
                label = { Text("رقم الشاسي") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_chassis_no")
            )
        }

        // المبالغ المالية
        FormSectionCard(title = "المبالغ المالية", icon = Icons.Default.Money) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { v -> onContractChange { it.copy(totalPrice = v) } },
                label = { Text("بدل قدره (بالأرقام أو كتابةً)") },
                leadingIcon = { Icon(Icons.Default.Money, contentDescription = null) },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_total_price")
            )

            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { v -> onContractChange { it.copy(totalPriceWords = v) } },
                label = { Text("المبلغ كتابةً (مثال: عشرة ملايين دينار)") },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_price_words")
            )

            ClearableOutlinedTextField(
                value = contract.paidAmount,
                onValueChange = { v -> onContractChange { it.copy(paidAmount = v) } },
                label = { Text("المبلغ المستلم") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_paid_amount")
            )

            ClearableOutlinedTextField(
                value = contract.remainingAmount,
                onValueChange = { v -> onContractChange { it.copy(remainingAmount = v) } },
                label = { Text("المبلغ المتبقي") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_car_remaining_amount")
            )
        }

        // التحرير والتوقيع
        FormSectionCard(title = "تاريخ العقد والشهود", icon = Icons.Default.CalendarToday) {
            com.example.DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { v -> onContractChange { it.copy(contractDate = v) } },
                label = "حرر بتاريخ",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_car_date"
            )

            val witness1Val = if (contract.witness1Name.isNotBlank()) contract.witness1Name else contract.witnessName
            ClearableOutlinedTextField(
                value = witness1Val,
                onValueChange = { v -> onContractChange { it.copy(witness1Name = v, witnessName = v) } },
                label = { Text("اسم الشاهد الأول") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_witness1")
            )

            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { v -> onContractChange { it.copy(witness2Name = v) } },
                label = { Text("اسم الشاهد الثاني") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_witness2")
            )

            ClearableOutlinedTextField(
                value = contract.organizerName,
                onValueChange = { v -> onContractChange { it.copy(organizerName = v) } },
                label = { Text("اسم منظم العقد") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_car_organizer")
            )
        }
    }
}
