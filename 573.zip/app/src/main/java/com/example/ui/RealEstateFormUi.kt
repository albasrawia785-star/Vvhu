package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.RealEstateContract
import com.example.ClearableOutlinedTextField
import com.example.FormSectionCard

@Composable
fun RealEstateFormUi(
    contract: RealEstateContract,
    onContractChange: ((RealEstateContract) -> RealEstateContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة رقم العقد والترويسة الفاخرة
        Surface(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Surface(
                        shape = androidx.compose.foundation.shape.CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.HomeWork,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "عقد بيع وشراء عقار (A4)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                ClearableOutlinedTextField(
                    value = contract.contractNo,
                    onValueChange = { newVal -> onContractChange { it.copy(contractNo = newVal) } },
                    label = { Text("رقم العقد") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_real_estate_no"),
                    textStyle = TextStyle(fontWeight = FontWeight.Bold)
                )
            }
        }

        // 1. قسم الطرف الأول (البائع)
        FormSectionCard(title = "الطرف الأول ( البائع )", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { valName -> onContractChange { it.copy(sellerName = valName) } },
                label = { Text("اسم البائع الثلاثي/الرباعي") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_seller_name")
            )

            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { v -> onContractChange { it.copy(sellerAddress = v) } },
                label = { Text("العنوان / السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_seller_address")
            )

            val sellerPhoneError = com.example.ContractValidation.validatePhone(contract.sellerPhone, "هاتف البائع")
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { v -> onContractChange { it.copy(sellerPhone = v) } },
                label = { Text("رقم الهاتف (11 رقم)") },
                isError = sellerPhoneError != null,
                supportingText = sellerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_seller_phone")
            )

            val sellerIdError = com.example.ContractValidation.validateNationalId(contract.sellerIdNumber, "بطاقة البائع")
            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { v -> onContractChange { it.copy(sellerIdNumber = v) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = sellerIdError != null,
                supportingText = sellerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("input_seller_id")
            )
        }

        // 2. قسم الطرف الثاني (المشتري)
        FormSectionCard(title = "الطرف الثاني ( المشتري )", icon = Icons.Default.AccountBox) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { v -> onContractChange { it.copy(buyerName = v) } },
                label = { Text("اسم المشتري الثلاثي/الرباعي") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_buyer_name")
            )

            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { v -> onContractChange { it.copy(buyerAddress = v) } },
                label = { Text("العنوان / السكن") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_buyer_address")
            )

            val buyerPhoneError = com.example.ContractValidation.validatePhone(contract.buyerPhone, "هاتف المشتري")
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { v -> onContractChange { it.copy(buyerPhone = v) } },
                label = { Text("رقم الهاتف (11 رقم)") },
                isError = buyerPhoneError != null,
                supportingText = buyerPhoneError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_buyer_phone")
            )

            val buyerIdError = com.example.ContractValidation.validateNationalId(contract.buyerIdNumber, "بطاقة المشتري")
            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { v -> onContractChange { it.copy(buyerIdNumber = v) } },
                label = { Text("رقم البطاقة الوطنية (12 رقم)") },
                isError = buyerIdError != null,
                supportingText = buyerIdError?.let { { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) } },
                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("input_buyer_id")
            )
        }

        // 3. مواصفات وتفاصيل العقار
        FormSectionCard(title = "مواصفات العقار والملك المباع", icon = Icons.Default.HomeWork) {
            ClearableOutlinedTextField(
                value = contract.propertyType,
                onValueChange = { v -> onContractChange { it.copy(propertyType = v) } },
                label = { Text("نوع الملك (دار/أرض/زراعي)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_property_type")
            )

            ClearableOutlinedTextField(
                value = contract.propertyArea,
                onValueChange = { v -> onContractChange { it.copy(propertyArea = v) } },
                label = { Text("المساحة (م²)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_property_area")
            )

            ClearableOutlinedTextField(
                value = contract.plotSequenceNo,
                onValueChange = { v -> onContractChange { it.copy(plotSequenceNo = v) } },
                label = { Text("الرقم والتسلسل") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_property_seq")
            )

            ClearableOutlinedTextField(
                value = contract.neighborhood,
                onValueChange = { v -> onContractChange { it.copy(neighborhood = v) } },
                label = { Text("المحلة / المنطقة") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_property_neighborhood")
            )
        }

        // 4. المبالغ والتسوية المالية
        FormSectionCard(title = "المبالغ والشروط المالية (أرقام أو نصوص)", icon = Icons.Default.Money) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { v -> onContractChange { it.copy(totalPrice = v) } },
                label = { Text("بدل البيع الأصلي (بالأرقام)") },
                leadingIcon = { Icon(Icons.Default.Money, contentDescription = null) },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_total_price")
            )

            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { v -> onContractChange { it.copy(totalPriceWords = v) } },
                label = { Text("المبلغ كتابةً (مثال: مائة مليون دينار)") },
                maxLines = 3,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_total_price_words")
            )

            ClearableOutlinedTextField(
                value = contract.depositPrice,
                onValueChange = { v -> onContractChange { it.copy(depositPrice = v) } },
                label = { Text("العربون المقبوض") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_deposit_price")
            )

            ClearableOutlinedTextField(
                value = contract.remainingPrice,
                onValueChange = { v -> onContractChange { it.copy(remainingPrice = v) } },
                label = { Text("المبلغ المتبقي") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_remaining_price")
            )

            ClearableOutlinedTextField(
                value = contract.penaltySellerAmount,
                onValueChange = { v -> onContractChange { it.copy(penaltySellerAmount = v) } },
                label = { Text("تعويضات نكول البائع") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_penalty_seller")
            )

            ClearableOutlinedTextField(
                value = contract.penaltyBuyerAmount,
                onValueChange = { v -> onContractChange { it.copy(penaltyBuyerAmount = v) } },
                label = { Text("تعويضات نكول المشتري") },
                visualTransformation = com.example.MoneyVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("input_penalty_buyer")
            )
        }

        // 5. المكان والتاريخ والشهود
        FormSectionCard(title = "مكان وتاريخ العقد والشهود", icon = Icons.Default.CalendarToday) {
            ClearableOutlinedTextField(
                value = contract.contractPlace,
                onValueChange = { v -> onContractChange { it.copy(contractPlace = v) } },
                label = { Text("مكان تحرير العقد (مثال: البصرة - حي الحسين)") },
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_contract_place")
            )

            com.example.DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { v -> onContractChange { it.copy(contractDate = v) } },
                label = "تاريخ تحرير العقد",
                modifier = Modifier.fillMaxWidth(),
                testTag = "input_contract_date"
            )

            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { v -> onContractChange { it.copy(witness1Name = v) } },
                label = { Text("اسم الشاهد الأول") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_witness1")
            )

            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { v -> onContractChange { it.copy(witness2Name = v) } },
                label = { Text("اسم الشاهد الثاني") },
                maxLines = 2,
                minLines = 1,
                modifier = Modifier.fillMaxWidth().testTag("input_witness2")
            )

            ClearableOutlinedTextField(
                value = contract.additionalNotes,
                onValueChange = { v -> onContractChange { it.copy(additionalNotes = v) } },
                label = { Text("ملاحظات أو شروط إضافية") },
                minLines = 2,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth().testTag("input_additional_notes")
            )
        }
    }
}

@Composable
fun FormSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 6.dp)
    ) {
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Surface(
                shape = androidx.compose.foundation.shape.CircleShape,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = androidx.compose.ui.graphics.Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
