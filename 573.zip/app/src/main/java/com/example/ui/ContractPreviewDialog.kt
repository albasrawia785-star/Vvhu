package com.example.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.FormGenerator

@Composable
fun ContractPreviewDialog(
    bitmap: Bitmap?,
    onDismiss: () -> Unit,
    onPrintBluetooth: () -> Unit,
    onSaveContract: () -> Unit,
    onSaveAndPrint: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (bitmap == null) return

    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxSize()
                .padding(12.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            shadowElevation = 12.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // شريط العنوان العلوي
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "معاينة وثيقة العقد الرسمية (A4)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "مقاس قياسي 210 × 297 mm - جاهز للطباعة الحية",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("btn_close_preview")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                // حاوية عرض العقد والأزرار ملاصقة له أسفله مباشرة
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFE2E8F0)),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. معاينة ورقة العقد الرسمية
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(6.dp, RoundedCornerShape(4.dp))
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "معاينة العقد A4",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                            )
                        }

                        // 2. مسافة فاصلة دقيقة (16dp) أسفل ورقة العقد مباشرة
                        Spacer(modifier = Modifier.height(16.dp))

                        // 3. الأزرار ملاصقة لمعاينة العقد وبشكل متجانس وتفاعلي
                        ContractPreviewButtons(
                            onPrintBluetooth = onPrintBluetooth,
                            onSaveContract = {
                                onSaveContract()
                                Toast.makeText(context, "تم حفظ العقد في الأرشيف المحلي بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            onSaveAndPrint = onSaveAndPrint
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

/**
 * أزرار التحكم والطباعة بحجم متساوي واستجابة ذكية لحجم الشاشة (بدون خيار طباعة PDF بناءً على طلب المستخدم)
 */
@Composable
private fun ContractPreviewButtons(
    onPrintBluetooth: () -> Unit,
    onSaveContract: () -> Unit,
    onSaveAndPrint: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val buttonHeight = 50.dp
        val cornerShape = RoundedCornerShape(14.dp)

        // 1. زر حفظ وطباعة (الزر الأساسي البارز)
        Button(
            onClick = onSaveAndPrint,
            modifier = Modifier
                .fillMaxWidth()
                .height(buttonHeight)
                .testTag("btn_save_and_print"),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1E65FF),
                contentColor = Color.White
            ),
            shape = cornerShape
        ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("حفظ وطباعة A4", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 2. طباعة A4 فقط
            OutlinedButton(
                onClick = onPrintBluetooth,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("btn_print_bluetooth_dialog"),
                shape = cornerShape,
                border = BorderStroke(1.5.dp, Color(0xFF1E65FF)),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Icon(Icons.Default.Print, contentDescription = null, tint = Color(0xFF1E65FF), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("طباعة فقط", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E65FF), maxLines = 1)
            }

            // 3. حفظ في الأرشيف فقط
            ElevatedButton(
                onClick = onSaveContract,
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("btn_save_contract_archive"),
                colors = ButtonDefaults.elevatedButtonColors(
                    containerColor = Color(0xFFF1F5F9),
                    contentColor = Color(0xFF0F172A)
                ),
                shape = cornerShape
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ بالأرشيف", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}


