package com.example

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

/**
 * أدوات تنسيق الأرقام والتواريخ لعقود A4 الرسمية
 */
object FormatUtils {

    /**
     * إرجاع تاريخ اليوم الحالي بتنسيق YYYY/MM/DD (مثال: 2026/07/28)
     */
    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        return sdf.format(Date())
    }

    /**
     * تنسيق المبالغ المالية بإضافة فوارز الآلاف (مثال: 1000000 -> 1,000,000) مع دعم إدخال النصوص والكلمات
     */
    fun formatMoneyInput(rawInput: String): String {
        if (rawInput.isBlank()) return ""

        // تحويل الأرقام الشرقية/العربية إلى أرقام إنجليزية
        val westernDigitsStr = rawInput.map { ch ->
            when (ch) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
                '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                else -> ch
            }
        }.joinToString("")

        // إذا كان المدخل يتكون فقط من أرقام وفوارز ومسافات
        val digitsOnly = westernDigitsStr.replace(",", "").replace(" ", "").trim()
        val parsedNumber = digitsOnly.toLongOrNull()

        if (parsedNumber != null) {
            return String.format(Locale.US, "%,d", parsedNumber)
        }

        // إذا كان النص يحتوي على مزيج من أرقام وكلمات (مثل: 1000000 دينار)
        val numberBlockRegex = Regex("[0-9][0-9,]*[0-9]|[0-9]")
        return numberBlockRegex.replace(westernDigitsStr) { match ->
            val rawNum = match.value.replace(",", "")
            val parsed = rawNum.toLongOrNull()
            if (parsed != null) {
                String.format(Locale.US, "%,d", parsed)
            } else {
                match.value
            }
        }
    }
}

/**
 * زر مسح سريع للحقول النصية
 */
@Composable
fun ClearIconButton(
    value: String,
    onClear: () -> Unit
) {
    if (value.isNotEmpty()) {
        IconButton(
            onClick = onClear,
            modifier = Modifier.testTag("btn_clear_input")
        ) {
            Icon(
                imageVector = Icons.Default.Clear,
                contentDescription = "مسح النص",
                tint = MaterialTheme.colorScheme.outline
            )
        }
    }
}

/**
 * حقل نصي قياسي معتمد لجميع استمارات المخرجات بتصميم Material 3 الموحد المطابق للتصميم المرفق
 */
@Composable
fun ClearableOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    textStyle: TextStyle = TextStyle.Default,
    label: @Composable (() -> Unit)? = null,
    placeholder: @Composable (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = { ClearIconButton(value = value, onClear = { onValueChange("") }) },
    supportingText: @Composable (() -> Unit)? = null,
    isError: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    minLines: Int = 1,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    shape: Shape = RoundedCornerShape(12.dp),
    colors: TextFieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Color(0xFF1E65FF),
        unfocusedBorderColor = Color(0xFFCBD5E1),
        disabledBorderColor = Color(0xFFE2E8F0),
        errorBorderColor = Color(0xFFEF4444),
        focusedTextColor = Color(0xFF0F172A),
        unfocusedTextColor = Color(0xFF0F172A),
        disabledTextColor = Color(0xFF64748B),
        errorTextColor = Color(0xFF0F172A),
        focusedPlaceholderColor = Color(0xFF94A3B8),
        unfocusedPlaceholderColor = Color(0xFF94A3B8),
        focusedLeadingIconColor = Color(0xFF091E42),
        unfocusedLeadingIconColor = Color(0xFF091E42),
        focusedTrailingIconColor = Color(0xFF1E65FF),
        unfocusedTrailingIconColor = Color(0xFF64748B),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )
) {
    val unifiedTextStyle = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        lineHeight = 24.sp,
        color = Color(0xFF0F172A),
        textAlign = TextAlign.Start
    ).merge(textStyle)

    val styledLeadingIcon: @Composable (() -> Unit) = {
        Surface(
            shape = CircleShape,
            color = Color(0xFFEFF6FF),
            modifier = Modifier
                .padding(start = 8.dp, end = 4.dp)
                .size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                CompositionLocalProvider(LocalContentColor provides Color(0xFF091E42)) {
                    if (leadingIcon != null) {
                        leadingIcon()
                    } else {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        if (label != null) {
            CompositionLocalProvider(
                LocalTextStyle provides TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Start
                )
            ) {
                Box(modifier = Modifier.padding(bottom = 6.dp)) {
                    label()
                }
            }
        }

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 54.dp),
            enabled = enabled,
            readOnly = readOnly,
            textStyle = unifiedTextStyle,
            label = null,
            placeholder = placeholder,
            leadingIcon = styledLeadingIcon,
            trailingIcon = trailingIcon,
            supportingText = supportingText,
            isError = isError,
            visualTransformation = visualTransformation,
            keyboardOptions = keyboardOptions,
            keyboardActions = keyboardActions,
            singleLine = singleLine,
            maxLines = maxLines,
            minLines = minLines,
            interactionSource = interactionSource,
            shape = shape,
            colors = colors
        )
    }
}

/**
 * بطاقة مقطع هيدر مع الحقول بتصميم منظم مثل الصورة المرفقة
 */
@Composable
fun FormSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Description,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF091E42),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF091E42)
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(20.dp)
                        .background(Color(0xFF091E42), RoundedCornerShape(2.dp))
                )
            }
            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

            content()
        }
    }
}

/**
 * مكون حقل تاريخ تفاعلي مع تقويم لاختيار التاريخ بسهولة
 */
@Composable
fun DatePickerTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val formattedDate = String.format(Locale.US, "%04d/%02d/%02d", year, month + 1, dayOfMonth)
            onValueChange(formattedDate)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    ClearableOutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.testTag(testTag),
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "التاريخ") },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ClearIconButton(value = value, onClear = { onValueChange("") })
                IconButton(onClick = { datePickerDialog.show() }) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "اختر من التقويم",
                        tint = Color(0xFF1E65FF)
                    )
                }
            }
        }
    )
}

/**
 * تحويل بصرى لإظهار الفوارز التلقائية للمبالغ المالية بدون تعديل نص IME لمنع تبديل لوحة المفاتيح
 */
class MoneyVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val originalText = text.text
        if (originalText.isBlank()) {
            return TransformedText(text, OffsetMapping.Identity)
        }

        val transformedText = FormatUtils.formatMoneyInput(originalText)
        if (transformedText == originalText) {
            return TransformedText(text, OffsetMapping.Identity)
        }

        val origToTrans = IntArray(originalText.length + 1)
        val transToOrig = IntArray(transformedText.length + 1)

        var origIdx = 0
        var transIdx = 0

        while (origIdx < originalText.length && transIdx < transformedText.length) {
            transToOrig[transIdx] = origIdx
            val origChar = originalText[origIdx]
            val transChar = transformedText[transIdx]

            if (origChar == transChar) {
                origToTrans[origIdx] = transIdx
                origIdx++
                transIdx++
            } else if (transChar == ',') {
                transIdx++
            } else {
                origToTrans[origIdx] = transIdx
                origIdx++
                transIdx++
            }
        }

        while (origIdx <= originalText.length) {
            origToTrans[origIdx] = transformedText.length
            origIdx++
        }

        while (transIdx <= transformedText.length) {
            transToOrig[transIdx] = originalText.length
            transIdx++
        }

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                val clamped = offset.coerceIn(0, originalText.length)
                return origToTrans[clamped].coerceIn(0, transformedText.length)
            }

            override fun transformedToOriginal(offset: Int): Int {
                val clamped = offset.coerceIn(0, transformedText.length)
                return transToOrig[clamped].coerceIn(0, originalText.length)
            }
        }

        return TransformedText(AnnotatedString(transformedText), offsetMapping)
    }
}
