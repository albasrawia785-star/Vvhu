package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    HOME,
    REAL_ESTATE_FORM,
    CAR_SALE_FORM,
    RENTAL_FORM,
    MOTORCYCLE_FORM,
    SAVED_CONTRACTS,
    CONTRACT_TEMPLATES
}

class MainActivity : ComponentActivity() {

    private val viewModel: ContractViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainContractAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContractAppScreen(viewModel: ContractViewModel) {
    val context = LocalContext.current

    val selectedType by viewModel.selectedContractType.collectAsStateWithLifecycle()
    val realEstateData by viewModel.realEstateContract.collectAsStateWithLifecycle()
    val carSaleData by viewModel.carSaleContract.collectAsStateWithLifecycle()
    val rentalData by viewModel.rentalContract.collectAsStateWithLifecycle()
    val motorcycleData by viewModel.motorcycleContract.collectAsStateWithLifecycle()

    val previewBitmap by viewModel.previewBitmap.collectAsStateWithLifecycle()
    val showPreviewDialog by viewModel.showPreviewDialog.collectAsStateWithLifecycle()

    val printerState by viewModel.printerState.collectAsStateWithLifecycle()
    val pairedDevices by viewModel.pairedDevices.collectAsStateWithLifecycle()
    val selectedPaperType by viewModel.selectedPaperType.collectAsStateWithLifecycle()
    val showPrinterDialog by viewModel.showPrinterDialog.collectAsStateWithLifecycle()

    val savedContractsList by viewModel.savedContractsList.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }

    var validationErrors by remember { mutableStateOf<List<String>?>(null) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun runWithValidation(action: () -> Unit) {
        val result = when (selectedType) {
            ContractType.REAL_ESTATE -> ContractValidation.validateRealEstateContract(realEstateData)
            ContractType.CAR_SALE -> ContractValidation.validateCarSaleContract(carSaleData)
            ContractType.RENTAL -> ContractValidation.validateRentalContract(rentalData)
            ContractType.MOTORCYCLE -> ContractValidation.validateMotorcycleContract(motorcycleData)
        }
        if (result.isValid) {
            action()
        } else {
            validationErrors = result.errors.values.toList()
            pendingAction = action
        }
    }

    // إذن البلوتوث بنظام أندرويد 12+
    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            viewModel.openBluetoothPrinterDialog()
        } else {
            Toast.makeText(context, "يتطلب تطبيق الطباعة الإذن بالوصول للبلوتوث", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkAndOpenBluetoothPrinter() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val connectGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

            val scanGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

            if (connectGranted && scanGranted) {
                viewModel.openBluetoothPrinterDialog()
            } else {
                bluetoothPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            }
        } else {
            viewModel.openBluetoothPrinterDialog()
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen != AppScreen.HOME) {
                TopAppBar(
                    title = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val screenTitle = when (currentScreen) {
                                AppScreen.REAL_ESTATE_FORM -> "عقد بيع عقار"
                                AppScreen.CAR_SALE_FORM -> "عقد بيع سيارة"
                                AppScreen.RENTAL_FORM -> "عقد إيجار"
                                AppScreen.MOTORCYCLE_FORM -> "عقد بيع دراجة/تكتك/ستوتة"
                                AppScreen.SAVED_CONTRACTS -> "سجل العقود المحفوظة"
                                else -> "عقود برو"
                            }
                            Text(
                                text = screenTitle,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 19.sp
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(1.dp)
                                        .background(Color(0xFF60A5FA))
                                )
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .size(5.dp)
                                        .background(Color(0xFF60A5FA), CircleShape)
                                )
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(1.dp)
                                        .background(Color(0xFF60A5FA))
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            IconButton(onClick = { currentScreen = AppScreen.HOME }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "الرجوع للرئيسية",
                                    tint = Color.White
                                )
                            }
                        }
                    },
                    actions = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            // مؤشر حالة الطابعة المباشر في شريط العنوان
                            val printerDotColor = when (printerState) {
                                is PrinterState.Success -> Color(0xFF10B981)
                                is PrinterState.Connecting, is PrinterState.Printing, is PrinterState.Scanning -> Color(0xFFF59E0B)
                                is PrinterState.Error -> Color(0xFFEF4444)
                                else -> Color(0xFF94A3B8)
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                IconButton(
                                    onClick = { checkAndOpenBluetoothPrinter() },
                                    modifier = Modifier.size(36.dp).testTag("top_bar_bluetooth_btn")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Print,
                                            contentDescription = "حالة الطابعة",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .align(Alignment.TopEnd)
                                                .background(printerDotColor, CircleShape)
                                        )
                                    }
                                }
                            }

                            if (currentScreen == AppScreen.REAL_ESTATE_FORM ||
                                currentScreen == AppScreen.CAR_SALE_FORM ||
                                currentScreen == AppScreen.RENTAL_FORM ||
                                currentScreen == AppScreen.MOTORCYCLE_FORM) {
                                // 1. زر إفراغ جميع الحقول
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFEF4444).copy(alpha = 0.25f)
                                ) {
                                    TextButton(
                                        onClick = { showClearConfirmDialog = true },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("btn_clear_fields_top")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteSweep,
                                            contentDescription = "إفراغ الحقول",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إفراغ الحقول", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                // 2. زر معاينة العقد
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFF1E65FF)
                                ) {
                                    TextButton(
                                        onClick = { runWithValidation { viewModel.openPreviewDialog() } },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("btn_preview_contract_top")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Visibility,
                                            contentDescription = "معاينة",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("معاينة العقد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF091E42)
                    )
                )
            }
        },
        bottomBar = {},
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreenUi(
                        onSelectRealEstate = {
                            viewModel.setContractType(ContractType.REAL_ESTATE)
                            currentScreen = AppScreen.REAL_ESTATE_FORM
                        },
                        onSelectCarSale = {
                            viewModel.setContractType(ContractType.CAR_SALE)
                            currentScreen = AppScreen.CAR_SALE_FORM
                        },
                        onSelectRental = {
                            viewModel.setContractType(ContractType.RENTAL)
                            currentScreen = AppScreen.RENTAL_FORM
                        },
                        onSelectMotorcycle = {
                            viewModel.setContractType(ContractType.MOTORCYCLE)
                            currentScreen = AppScreen.MOTORCYCLE_FORM
                        },
                        onSelectSavedContracts = {
                            currentScreen = AppScreen.SAVED_CONTRACTS
                        },
                        onSelectPrinter = {
                            checkAndOpenBluetoothPrinter()
                        },
                        onSelectSettings = {
                            showSettingsDialog = true
                        },
                        onSelectContractTemplates = {
                            currentScreen = AppScreen.CONTRACT_TEMPLATES
                        },
                        onMenuClick = {
                            Toast.makeText(context, "منظومة عقود برو للطباعة الرسمية A4", Toast.LENGTH_SHORT).show()
                        },
                        onNotificationClick = {
                            Toast.makeText(context, "الطابعة متصلة وجاهزة لطباعة العقود", Toast.LENGTH_SHORT).show()
                        },
                        savedContractsCount = savedContractsList.size,
                        printerState = printerState
                    )
                }

                AppScreen.REAL_ESTATE_FORM -> {
                    RealEstateFormUi(
                        contract = realEstateData,
                        onContractChange = { update -> viewModel.updateRealEstateContract(update) }
                    )
                }

                AppScreen.CAR_SALE_FORM -> {
                    CarSaleFormUi(
                        contract = carSaleData,
                        onContractChange = { update -> viewModel.updateCarSaleContract(update) }
                    )
                }

                AppScreen.RENTAL_FORM -> {
                    RentalFormUi(
                        contract = rentalData,
                        onContractChange = { update -> viewModel.updateRentalContract(update) }
                    )
                }

                AppScreen.MOTORCYCLE_FORM -> {
                    MotorcycleFormUi(
                        contract = motorcycleData,
                        onContractChange = { update -> viewModel.updateMotorcycleContract(update) }
                    )
                }

                AppScreen.SAVED_CONTRACTS -> {
                    SavedContractsScreen(
                        contracts = savedContractsList,
                        onDeleteContract = { id -> viewModel.deleteSavedContract(id) },
                        onReprintContract = { entity ->
                            viewModel.loadContractFromArchive(entity)
                        }
                    )
                }

                AppScreen.CONTRACT_TEMPLATES -> {
                    ContractTemplatesScreen(
                        onBack = { currentScreen = AppScreen.HOME },
                        onTemplateChanged = { viewModel.refreshOfficeInfo() }
                    )
                }
            }
        }
    }

    // 1. حوار معاينة العقد وإنشاء الـ PDF
    if (showPreviewDialog) {
        ContractPreviewDialog(
            bitmap = previewBitmap,
            onDismiss = { viewModel.closePreviewDialog() },
            onPrintBluetooth = {
                val paired = viewModel.bluetoothPrinterManager.getPairedDevices()
                if (paired.isEmpty()) {
                    Toast.makeText(
                        context,
                        "تنبيه: لا توجد طابعة بلوتوث مقترنة! يرجى إقران طابعة عبر البلوتوث أولاً.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                viewModel.closePreviewDialog()
                checkAndOpenBluetoothPrinter()
            },
            onSaveContract = {
                viewModel.saveContractToArchive()
            },
            onSaveAndPrint = {
                val paired = viewModel.bluetoothPrinterManager.getPairedDevices()
                if (paired.isEmpty()) {
                    Toast.makeText(
                        context,
                        "تنبيه: لا يمكن الحفظ والطباعة معاً! لا توجد طابعة بلوتوث مقترنة بالهاتف حالياً. يرجى إقران طابعة أولاً.",
                        Toast.LENGTH_LONG
                    ).show()
                    viewModel.openBluetoothPrinterDialog()
                } else {
                    viewModel.saveContractToArchive()
                    viewModel.closePreviewDialog()
                    checkAndOpenBluetoothPrinter()
                    Toast.makeText(
                        context,
                        "تم حفظ العقد بنجاح في الأرشيف وتوجيهه للطباعة عبر الطابعة المقترنة!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )
    }

    // حوار تأكيد إفراغ جميع الحقول
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = {
                Text(
                    text = "إفراغ جميع الحقول",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من مسح وإفراغ جميع البيانات والحقول المكتوبة حالياً للعقد؟",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearConfirmDialog = false
                        viewModel.clearCurrentContractFields()
                        Toast.makeText(context, "تم إفراغ جميع الحقول بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("مسح وإفراغ")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 2. حوار الطباعة عبر البلوتوث
    if (showPrinterDialog) {
        BluetoothPrinterDialog(
            printerState = printerState,
            pairedDevices = pairedDevices,
            selectedPaperType = selectedPaperType,
            onSelectPaperType = { type -> viewModel.setPrinterPaperType(type) },
            onRefreshDevices = { viewModel.refreshPairedDevices() },
            onSelectDevice = { device -> viewModel.printToBluetoothDevice(device) },
            onDismiss = { viewModel.closeBluetoothPrinterDialog() }
        )
    }

    // 3. حوار الإعدادات
    if (showSettingsDialog) {
        SettingsDialog(
            onDismiss = { showSettingsDialog = false },
            onOpenPrinterDialog = { checkAndOpenBluetoothPrinter() },
            onOpenContractTemplates = { currentScreen = AppScreen.CONTRACT_TEMPLATES },
            onSettingsSaved = { viewModel.refreshOfficeInfo() }
        )
    }

    // 4. حوار التحقق من صحة البيانات (Form Validation)
    if (validationErrors != null) {
        AlertDialog(
            onDismissRequest = {
                validationErrors = null
                pendingAction = null
            },
            title = {
                Text(
                    "تنبيه: تدقيق البيانات قبل الطباعة",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("يرجى التأكد من الحقول التالية للحفاظ على رسمية واحترافية العقد:", fontSize = 14.sp)
                    validationErrors?.forEach { err ->
                        Text("• $err", color = MaterialTheme.colorScheme.error, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val act = pendingAction
                        validationErrors = null
                        pendingAction = null
                        act?.invoke()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("متابعة على أي حال")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        validationErrors = null
                        pendingAction = null
                    }
                ) {
                    Text("تعديل البيانات")
                }
            }
        )
    }
}
