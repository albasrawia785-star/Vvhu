package com.example

import android.content.Context
import android.graphics.Bitmap

/**
 * مدير قوالب ورسامات العقود (ContractTemplateManager)
 * المسؤول عن:
 * - تحميل قالب العقد والجهات الرسومية الخاصة به.
 * - إرجاع الـ BaseContractRenderer الخاص بالعقد.
 * - تحويل بيانات أي عقد إلى Bitmap جاهز للطباعة أو المعاينة.
 * - توفير معمارية مرنة تتيح إضافة عقد جديد في المستقبل بإنشاء Data Class و Renderer فقط دون تعديل أي ملف أساسي آخر.
 */
object ContractTemplateManager {

    private val templates = mapOf(
        ContractType.REAL_ESTATE to ContractTemplate(
            id = "tmpl_real_estate",
            nameAr = "عقد بيع وشراء عقار",
            descriptionAr = "الدور والاراضي السكنية والزراعية",
            contractType = ContractType.REAL_ESTATE,
            headerImageAssetLeft = "ic_real_estate_left",
            headerImageAssetRight = "ic_real_estate_right"
        ),
        ContractType.CAR_SALE to ContractTemplate(
            id = "tmpl_car_sale",
            nameAr = "عقد بيع وشراء السيارات",
            descriptionAr = "لتجارة السيارات الحديثة",
            contractType = ContractType.CAR_SALE,
            headerImageAssetLeft = "ic_car_header_left",
            headerImageAssetRight = "ic_car_header_right"
        ),
        ContractType.RENTAL to ContractTemplate(
            id = "tmpl_rental",
            nameAr = "عقد ايجار",
            descriptionAr = "بيع وشراء الدور والاراضي السكنية",
            contractType = ContractType.RENTAL,
            headerImageAssetLeft = "ic_rental_header_left",
            headerImageAssetRight = "ic_rental_header_right"
        ),
        ContractType.MOTORCYCLE to ContractTemplate(
            id = "tmpl_motorcycle",
            nameAr = "عقد بيع وشراء",
            descriptionAr = "الدراجات والتكتك والستوتات",
            contractType = ContractType.MOTORCYCLE,
            headerImageAssetLeft = "ic_motorcycle_header_left",
            headerImageAssetRight = "ic_motorcycle_header_right"
        )
    )

    private val renderers = mapOf<ContractType, BaseContractRenderer>(
        ContractType.REAL_ESTATE to RealEstateContractRenderer(),
        ContractType.CAR_SALE to CarSaleContractRenderer(),
        ContractType.RENTAL to RentalContractRenderer(),
        ContractType.MOTORCYCLE to MotorcycleContractRenderer()
    )

    /**
     * الحصول على قالب العقد
     */
    fun getTemplate(contractType: ContractType): ContractTemplate {
        return templates[contractType] ?: ContractTemplate(
            id = "tmpl_fallback_${contractType.name}",
            nameAr = contractType.titleAr,
            descriptionAr = "استمارة عقد رسمية معتمدة",
            contractType = contractType
        )
    }

    /**
     * الحصول على محرك الرسم الخاص بنوع العقد
     */
    fun getRenderer(contractType: ContractType): BaseContractRenderer {
        return renderers[contractType] ?: RealEstateContractRenderer()
    }

    /**
     * رسم ورقة العقد بحجم A4
     */
    fun renderContractBitmap(
        contractType: ContractType,
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val renderer = getRenderer(contractType)
        return renderer.renderBitmap(contractData, officeInfo, context)
    }
}
